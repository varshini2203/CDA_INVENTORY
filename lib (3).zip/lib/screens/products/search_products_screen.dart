// lib/screens/products/search_products_screen.dart
//
// Search Products screen — two search modes on one page:
//   • Row Search  — filter chips for every distinct `row` value found in
//     the product list (e.g. "Row 1".."Row 5"), plus a text box that
//     narrows further by product name.
//   • Tray Search — same idea, but chips are every distinct `tray` value
//     (e.g. "Tray 1".."Tray 16", "Draw 1", "Table 2 - Draw 1"...).
//
// Drop-in usage:
//   Navigator.push(context, MaterialPageRoute(
//     builder: (_) => SearchProductsScreen(products: myProductList),
//   ));
//
// If `products` isn't supplied, the screen falls back to Branch 1's
// seed data (SeedBranch1Products) converted to Product objects, so this
// screen works standalone before a real ProductService is wired in —
// swap in your own list (e.g. from Firestore) via the constructor once
// that's ready, nothing else in this file needs to change.

import 'package:flutter/material.dart';

import 'package:cda_inventory/models/product.dart';
import 'package:cda_inventory/data/seed_branch1_products.dart';

/// Which physical dimension is currently being searched.
enum _SearchMode { row, tray }

class SearchProductsScreen extends StatefulWidget {
  final List<Product>? products;
  final String title;

  const SearchProductsScreen({
    super.key,
    this.products,
    this.title = 'Search Products',
  });

  @override
  State<SearchProductsScreen> createState() => _SearchProductsScreenState();
}

class _SearchProductsScreenState extends State<SearchProductsScreen>
    with SingleTickerProviderStateMixin {
  // ── Design tokens (matches Branch Inventory / Invoices theme) ──────────
  static const Color kNavy = Color(0xFF0A1628);
  static const Color kTeal = Color(0xFF00D4AA);
  static const Color kCoral = Color(0xFFFF6B6B);
  static const Color kAmber = Color(0xFFFFB800);
  static const Color kSurface = Color(0xFFF0F4F8);
  static const Color kGreen = Color(0xFF00B894);
  static const Color kPurple = Color(0xFF6C63FF);

  late final TabController _tabController;
  late final List<Product> _allProducts;

  // One controller + query string per tab, kept independent so switching
  // tabs doesn't clear what you were searching for on the other one.
  final TextEditingController _rowSearchController = TextEditingController();
  final TextEditingController _traySearchController = TextEditingController();
  String _rowQuery = '';
  String _trayQuery = '';

  // null = "All" chip selected (no chip filter applied yet).
  String? _selectedRow;
  String? _selectedTray;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _allProducts = widget.products ?? _productsFromBranch1Seed();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _rowSearchController.dispose();
    _traySearchController.dispose();
    super.dispose();
  }

  /// Converts the raw Branch 1 seed maps into Product objects so this
  /// screen has something real to show even with no backend wired up.
  static List<Product> _productsFromBranch1Seed() {
    final items = SeedBranch1Products.allItems;
    return List<Product>.generate(items.length, (i) {
      final m = items[i];
      return Product(
        id: 'branch1_seed_$i',
        name: m['name'] as String? ?? '',
        category: m['category'] as String? ?? '',
        quantity: (m['quantity'] as num?)?.toInt() ?? 0,
        price: 0.0,
        notes: m['notes'] as String?,
        row: m['row'] as String?,
        rack: m['rack'] as String?,
        tray: m['tray'] as String?,
      );
    });
  }

  // ── Distinct chip values, sorted so "Row 2" sorts before "Row 10" ──────
  List<String> get _distinctRows => _distinctSorted(_allProducts.map((p) => p.row));
  List<String> get _distinctTrays => _distinctSorted(_allProducts.map((p) => p.tray));

  static List<String> _distinctSorted(Iterable<String?> values) {
    final set = <String>{
      for (final v in values)
        if ((v ?? '').trim().isNotEmpty) v!.trim(),
    };
    final list = set.toList();
    list.sort((a, b) {
      final na = RegExp(r'\d+').firstMatch(a);
      final nb = RegExp(r'\d+').firstMatch(b);
      if (na != null && nb != null) {
        final byNum = int.parse(na.group(0)!).compareTo(int.parse(nb.group(0)!));
        if (byNum != 0) return byNum;
      }
      return a.compareTo(b);
    });
    return list;
  }

  List<Product> get _rowResults {
    return _allProducts.where((p) {
      if (_selectedRow != null && p.row != _selectedRow) return false;
      if (_rowQuery.trim().isEmpty) return true;
      final q = _rowQuery.trim().toLowerCase();
      return p.name.toLowerCase().contains(q) ||
          (p.row ?? '').toLowerCase().contains(q);
    }).toList();
  }

  List<Product> get _trayResults {
    return _allProducts.where((p) {
      if (_selectedTray != null && p.tray != _selectedTray) return false;
      if (_trayQuery.trim().isEmpty) return true;
      final q = _trayQuery.trim().toLowerCase();
      return p.name.toLowerCase().contains(q) ||
          (p.tray ?? '').toLowerCase().contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSurface,
      appBar: AppBar(
        backgroundColor: kNavy,
        foregroundColor: Colors.white,
        title: Text(widget.title),
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: kTeal,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white70,
          tabs: const [
            Tab(icon: Icon(Icons.view_agenda_outlined), text: 'Row Search'),
            Tab(icon: Icon(Icons.inbox_outlined), text: 'Tray Search'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          _SearchPane(
            mode: _SearchMode.row,
            chips: _distinctRows,
            selectedChip: _selectedRow,
            onChipSelected: (v) => setState(() => _selectedRow = v),
            searchController: _rowSearchController,
            onQueryChanged: (v) => setState(() => _rowQuery = v),
            results: _rowResults,
            chipColor: kTeal,
            hintText: 'Search by row or product name…',
            emptyLabel: 'No products found in this row.',
          ),
          _SearchPane(
            mode: _SearchMode.tray,
            chips: _distinctTrays,
            selectedChip: _selectedTray,
            onChipSelected: (v) => setState(() => _selectedTray = v),
            searchController: _traySearchController,
            onQueryChanged: (v) => setState(() => _trayQuery = v),
            results: _trayResults,
            chipColor: kPurple,
            hintText: 'Search by tray or product name…',
            emptyLabel: 'No products found in this tray.',
          ),
        ],
      ),
    );
  }
}

/// The shared body for both tabs: search box + filter chips + result list.
/// Kept as one widget so Row Search and Tray Search always stay visually
/// identical — only the data feeding it (chip values, results, color)
/// differs per tab.
class _SearchPane extends StatelessWidget {
  final _SearchMode mode;
  final List<String> chips;
  final String? selectedChip;
  final ValueChanged<String?> onChipSelected;
  final TextEditingController searchController;
  final ValueChanged<String> onQueryChanged;
  final List<Product> results;
  final Color chipColor;
  final String hintText;
  final String emptyLabel;

  const _SearchPane({
    required this.mode,
    required this.chips,
    required this.selectedChip,
    required this.onChipSelected,
    required this.searchController,
    required this.onQueryChanged,
    required this.results,
    required this.chipColor,
    required this.hintText,
    required this.emptyLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: TextField(
            controller: searchController,
            onChanged: onQueryChanged,
            decoration: InputDecoration(
              hintText: hintText,
              prefixIcon: const Icon(Icons.search),
              filled: true,
              fillColor: Colors.white,
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: BorderSide.none,
              ),
            ),
          ),
        ),
        SizedBox(
          height: 40,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: chips.length + 1, // +1 for "All"
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, i) {
              final isAll = i == 0;
              final label = isAll ? 'All' : chips[i - 1];
              final selected = isAll ? selectedChip == null : selectedChip == label;
              return ChoiceChip(
                label: Text(label),
                selected: selected,
                onSelected: (_) => onChipSelected(isAll ? null : label),
                selectedColor: chipColor,
                labelStyle: TextStyle(
                  color: selected ? Colors.white : Colors.black87,
                  fontWeight: selected ? FontWeight.w600 : FontWeight.normal,
                ),
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                  side: BorderSide(color: chipColor.withOpacity(0.4)),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(
              '${results.length} item${results.length == 1 ? '' : 's'}',
              style: const TextStyle(color: Colors.black54, fontSize: 13),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Expanded(
          child: results.isEmpty
              ? Center(
            child: Text(
              emptyLabel,
              style: const TextStyle(color: Colors.black45),
            ),
          )
              : ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            itemCount: results.length,
            itemBuilder: (context, i) => _ProductTile(
              product: results[i],
              highlightColor: chipColor,
            ),
          ),
        ),
      ],
    );
  }
}

class _ProductTile extends StatelessWidget {
  final Product product;
  final Color highlightColor;

  const _ProductTile({required this.product, required this.highlightColor});

  @override
  Widget build(BuildContext context) {
    // Built directly from the raw row/rack/tray fields (which already
    // read as "Row 3" / "Tray 7") rather than Product.locationLabel, to
    // avoid double-prefixing labels that already include their own word.
    final parts = <String>[
      if ((product.row ?? '').isNotEmpty) product.row!,
      if ((product.rack ?? '').isNotEmpty) product.rack!,
      if ((product.tray ?? '').isNotEmpty) product.tray!,
    ];
    final location = parts.join(' · ');

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
        side: BorderSide(color: Colors.black.withOpacity(0.06)),
      ),
      color: Colors.white,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    product.category,
                    style: const TextStyle(color: Colors.black54, fontSize: 12),
                  ),
                  if (location.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: highlightColor.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        location,
                        style: TextStyle(
                          color: highlightColor,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ],
                  if ((product.notes ?? '').isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      product.notes!,
                      style: const TextStyle(
                        color: Colors.black38,
                        fontSize: 11,
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: const Color(0xFFF0F4F8),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text(
                'x${product.quantity}',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
              ),
            ),
          ],
        ),
      ),
    );
  }
}