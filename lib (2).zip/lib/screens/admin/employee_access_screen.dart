// lib/screens/admin/employee_access_screen.dart
//
// Full employee roster for the admin, with live access-level control.
// Existing/legacy employees default to Viewer (via the one-tap "Sync
// legacy users" action); the admin manually promotes anyone who needs
// Editor access, or revokes access entirely.

import 'package:flutter/material.dart';
import 'admin_hero_banner.dart';

import '../../core/access/restricted_modules.dart';
import '../../models/app_access_models.dart';
import '../../services/access_control_service.dart';
import 'employee_activity_screen.dart';

class EmployeeAccessScreen extends StatelessWidget {
  const EmployeeAccessScreen({super.key});

  static const _bg = Color(0xFFF2F5FA);
  static const _card = Colors.white;
  static const _border = Color(0xFFD5DFEE);
  static const _blue = Color(0xFF1E5FC8);

  Future<void> _syncLegacyUsers(BuildContext context) async {
    final count = await AccessControlService.migrateLegacyUsersToViewer();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('$count existing employee(s) set to Viewer access')),
    );
  }

  // ── Hero banner ──────────────────────────────────────────────────────
  // Same drone/sunset artwork (pending.png) used on the Pending Requests
  // screen, with the page title + subtitle overlaid, and the "sync legacy
  // users" action pinned as a small circular button in the top-right
  // corner of the banner.
  //
  // Pulled into its own method (rather than inline in build()) so it can
  // sit in a SliverToBoxAdapter and scroll away with the rest of the page
  // — see the note at the bottom of this file for why that matters.
  Widget _buildHeroBanner(BuildContext context) {
    return AdminHeroBanner(
      bottomLeft: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Manage Employees',
            style: TextStyle(
                color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800),
          ),
          SizedBox(height: 3),
          Text(
            'View employees and control their access levels',
            style: TextStyle(color: Colors.white, fontSize: 12.5),
          ),
        ],
      ),
      // "Sync legacy users" — small circular button in the top-right.
      topRight: Material(
        color: Colors.black.withOpacity(0.35),
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: () => _syncLegacyUsers(context),
          child: Padding(
            padding: const EdgeInsets.all(9),
            child: Tooltip(
              message: 'Give every un-configured existing employee Viewer access',
              child: Icon(Icons.sync_rounded,
                  color: Color(0xFF374151), size: 19),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bg,
      appBar: AppBar(
        // Transparent — the page title/subtitle now live in the hero
        // banner below instead of a plain AppBar title, matching the
        // Pending Requests screen's treatment.
        backgroundColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: Color(0xFF111827)),
      ),
      // A single CustomScrollView for the ENTIRE page (hero banner + the
      // employee list) — everything scrolls together as one unit, same
      // as the dashboard screen. Previously the hero banner lived in a
      // fixed Column with only the employee list wrapped in its own
      // scrollable ListView beneath it; that meant the banner never
      // moved and the list only scrolled within the leftover space below
      // it, which read as "the page isn't scrolling" whenever the
      // banner + list together were taller than the screen.
      body: StreamBuilder<List<AppUserAccess>>(
        stream: AccessControlService.streamAllEmployees(),
        builder: (context, snapshot) {
          if (!snapshot.hasData && !snapshot.hasError) {
            return CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildHeroBanner(context)),
                const SliverFillRemaining(
                  hasScrollBody: false,
                  child: Padding(
                    padding: EdgeInsets.symmetric(vertical: 40),
                    child: Center(child: CircularProgressIndicator(color: _blue)),
                  ),
                ),
              ],
            );
          }
          if (snapshot.hasError) {
            return CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildHeroBanner(context)),
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.cloud_off_rounded, size: 40, color: Color(0xFF9CA3AF)),
                        const SizedBox(height: 12),
                        Text(
                          'Could not load employees.\n${snapshot.error}',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: Color(0xFF6B7280)),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            );
          }
          final users = snapshot.data!;
          if (users.isEmpty) {
            return CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                SliverToBoxAdapter(child: _buildHeroBanner(context)),
                SliverFillRemaining(
                  hasScrollBody: false,
                  child: Center(
                    child: Text('No employees yet',
                        style: TextStyle(color: Color(0xFF9CA3AF))),
                  ),
                ),
              ],
            );
          }
          return CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(child: _buildHeroBanner(context)),
              SliverPadding(
                padding: const EdgeInsets.all(14),
                sliver: SliverList(
                  delegate: SliverChildBuilderDelegate(
                        (context, i) => Padding(
                      padding: EdgeInsets.only(bottom: i == users.length - 1 ? 0 : 10),
                      child: _EmployeeCard(user: users[i]),
                    ),
                    childCount: users.length,
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _EmployeeCard extends StatelessWidget {
  final AppUserAccess user;
  const _EmployeeCard({required this.user});

  Color get _dotColor {
    switch (user.accessLevel) {
      case AccessLevel.editor:
        return Color(0xFF15803D);
      case AccessLevel.viewer:
        return Color(0xFFB7791F);
      case AccessLevel.none:
        return Color(0xFFD5DFEE);
    }
  }

  Future<void> _setLevel(BuildContext context, AccessLevel level) async {
    // NOTE: AccessControlService.setAccessLevel() already writes a proper
    // feed entry (module: 'Employees', with an access_level before/after
    // diff) for this exact change. There used to be a second logAction()
    // call here too, which meant every single Viewer/Editor click wrote
    // two rows to the Live Activity Feed for the same click — one under
    // "Employees" and a near-duplicate under "Access Control".
    await AccessControlService.setAccessLevel(userId: user.uid, level: level);
  }

  /// Grants/revokes one restricted finance module (Invoices / Sales /
  /// Purchases) for this employee. Writes the complete new set.
  Future<void> _toggleModule(BuildContext context, String key, bool grant) async {
    final next = {...user.moduleAccess};
    grant ? next.add(key) : next.remove(key);
    try {
      await AccessControlService.setModuleAccess(userId: user.uid, modules: next);
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not update module access: $e')),
      );
    }
  }

  Future<void> _confirmDelete(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        backgroundColor: EmployeeAccessScreen._card,
        title: const Text('Remove employee?', style: TextStyle(color: Color(0xFF111827))),
        content: Text(
          'This will permanently remove ${user.name.isNotEmpty ? user.name : user.email} '
              'and revoke all their access. This cannot be undone.',
          style: TextStyle(color: Color(0xFF374151)),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('Delete', style: TextStyle(color: Color(0xFFDC2626))),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    if (!context.mounted) return;

    try {
      await AccessControlService.removeEmployee(user.uid);
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${user.name.isNotEmpty ? user.name : user.email} removed')),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not remove employee: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: EmployeeAccessScreen._card,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: EmployeeAccessScreen._border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Top row: avatar, name/email/status, and the small "View"
          // (activity) button pinned to the top-right corner of the card.
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Stack(
                children: [
                  CircleAvatar(
                    radius: 18,
                    backgroundColor: EmployeeAccessScreen._blue.withOpacity(0.2),
                    child: Text(
                      user.name.isNotEmpty ? user.name[0].toUpperCase() : '?',
                      style: const TextStyle(color: Color(0xFF111827), fontWeight: FontWeight.bold),
                    ),
                  ),
                  if (user.isOnline)
                    Positioned(
                      right: 0,
                      bottom: 0,
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: BoxDecoration(
                          color: Color(0xFF15803D),
                          shape: BoxShape.circle,
                          border: Border.all(color: EmployeeAccessScreen._card, width: 2),
                        ),
                      ),
                    ),
                ],
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(user.name.isNotEmpty ? user.name : user.email,
                        style: const TextStyle(color: Color(0xFF111827), fontWeight: FontWeight.w700)),
                    Text(user.email,
                        style: TextStyle(color: Color(0xFF9CA3AF), fontSize: 11)),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Container(
                          width: 7,
                          height: 7,
                          decoration: BoxDecoration(color: _dotColor, shape: BoxShape.circle),
                        ),
                        const SizedBox(width: 5),
                        Text(
                          '${accessLevelToString(user.accessLevel)} · ${accessStatusToString(user.accessStatus)}',
                          style: TextStyle(color: Color(0xFF6B7280), fontSize: 11),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              // "View" — shows this employee's name together with every
              // page they visited and every action they took. Small and
              // pinned top-right, exactly where it's sketched.
              _ViewButton(
                onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(
                    settings: const RouteSettings(name: 'Employee Activity'),
                    builder: (_) => EmployeeActivityScreen(user: user),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              // "Delete" — permanently removes the employee (with a
              // confirmation dialog first). Pinned top-right next to View.
              _DeleteButton(onTap: () => _confirmDelete(context)),
            ],
          ),
          const SizedBox(height: 12),
          // ── Bottom row: Viewer / Editor / Revoke as three always-visible
          // buttons instead of a hidden 3-dot menu. The one matching the
          // employee's current access level is filled/highlighted.
          Row(
            children: [
              Expanded(
                child: _AccessButton(
                  label: 'Viewer',
                  active: user.accessLevel == AccessLevel.viewer,
                  color: Color(0xFFB7791F),
                  onTap: () => _setLevel(context, AccessLevel.viewer),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _AccessButton(
                  label: 'Editor',
                  active: user.accessLevel == AccessLevel.editor,
                  color: Color(0xFF15803D),
                  onTap: () => _setLevel(context, AccessLevel.editor),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _AccessButton(
                  label: 'Revoke',
                  active: user.accessLevel == AccessLevel.none,
                  color: Color(0xFFDC2626),
                  onTap: () => _setLevel(context, AccessLevel.none),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Divider(height: 1, color: Color(0xFFE5EAF3)),
          const SizedBox(height: 10),
          // ── Finance modules: Invoices / Sales / Purchases are hidden
          // from everyone except the people ticked here. Off by default.
          Row(
            children: const [
              Icon(Icons.lock_outline_rounded, size: 14, color: Color(0xFF6B7280)),
              SizedBox(width: 6),
              Text(
                'Finance modules this person can see',
                style: TextStyle(
                    color: Color(0xFF374151), fontSize: 11.5, fontWeight: FontWeight.w700),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 6,
            children: [
              for (final key in RestrictedModules.all)
                _ModuleChip(
                  moduleKey: key,
                  label: RestrictedModules.label(key),
                  selected: user.moduleAccess.contains(key),
                  onTap: () => _toggleModule(
                      context, key, !user.moduleAccess.contains(key)),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Small pill button pinned top-right of the card — opens the
/// per-employee activity trail (pages visited + actions taken).
class _ViewButton extends StatelessWidget {
  final VoidCallback onTap;
  const _ViewButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: EmployeeAccessScreen._blue.withOpacity(0.14),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: EmployeeAccessScreen._blue.withOpacity(0.5)),
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.history_rounded, size: 13, color: EmployeeAccessScreen._blue),
              SizedBox(width: 4),
              Text('View', style: TextStyle(fontSize: 11, color: EmployeeAccessScreen._blue, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}

/// Small pill button pinned top-right of the card, next to "View" —
/// permanently deletes the employee after a confirmation dialog.
class _DeleteButton extends StatelessWidget {
  final VoidCallback onTap;
  const _DeleteButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: Color(0xFFDC2626).withOpacity(0.14),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Color(0xFFDC2626).withOpacity(0.5)),
          ),
          child: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.delete_outline_rounded, size: 13, color: Color(0xFFDC2626)),
              SizedBox(width: 4),
              Text('Delete', style: TextStyle(fontSize: 11, color: Color(0xFFDC2626), fontWeight: FontWeight.w700)),
            ],
          ),
        ),
      ),
    );
  }
}

/// One of the three inline access-level buttons (Viewer / Editor / Revoke).
/// Filled with [color] when it's the employee's current access level,
/// outlined otherwise — so the active state is obvious at a glance without
/// needing to open anything.
class _AccessButton extends StatelessWidget {
  final String label;
  final bool active;
  final Color color;
  final VoidCallback onTap;
  const _AccessButton({
    required this.label,
    required this.active,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(8),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 8),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: active ? color.withOpacity(0.18) : Colors.transparent,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: active ? color : Color(0xFFD5DFEE)),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 12,
              color: active ? color : Color(0xFF6B7280),
              fontWeight: active ? FontWeight.w800 : FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }
}

/// Theme-independent toggle chip for the finance modules (Invoices / Sales /
/// Purchases). Selected = solid blue gradient pill with white text;
/// unselected = soft blue-grey pill with a muted icon. Each module has its
/// own icon.
class _ModuleChip extends StatelessWidget {
  final String moduleKey;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _ModuleChip({
    required this.moduleKey,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  IconData get _icon {
    switch (moduleKey) {
      case RestrictedModules.invoices:
        return Icons.receipt_long_rounded;
      case RestrictedModules.sales:
        return Icons.trending_up_rounded;
      case RestrictedModules.purchases:
        return Icons.shopping_cart_rounded;
      default:
        return Icons.folder_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(24),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 180),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
          decoration: BoxDecoration(
            gradient: selected
                ? const LinearGradient(
              colors: [Color(0xFF1E5FC8), Color(0xFF38A3F5)],
            )
                : null,
            color: selected ? null : const Color(0xFFEEF2F9),
            borderRadius: BorderRadius.circular(24),
            boxShadow: selected
                ? [
              BoxShadow(
                color: const Color(0xFF1E5FC8).withOpacity(0.30),
                blurRadius: 8,
                offset: const Offset(0, 3),
              ),
            ]
                : null,
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                _icon,
                size: 16,
                color: selected ? Colors.white : const Color(0xFF8A94A6),
              ),
              const SizedBox(width: 7),
              Text(
                label,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: selected ? FontWeight.w800 : FontWeight.w600,
                  color: selected ? Colors.white : const Color(0xFF6B7280),
                ),
              ),
              if (selected) ...[
                const SizedBox(width: 6),
                const Icon(Icons.check_rounded, size: 15, color: Colors.white),
              ],
            ],
          ),
        ),
      ),
    );
  }
}