// lib/screens/search/search_screen.dart
//
// Search Products screen — browses the shared `products` Firestore
// collection with three ways to slice it, matching how items are actually
// found on the shelf rather than just by name:
//
//   • By Category — the column headers from each source sheet (Tools,
//     Charging Station, Row 2, Service Rack, Admin Room, etc.)
//   • By Row      — Row 1 .. Row 5 (Branch 1 shelving)
//   • By Tray     — every distinct Tray/Draw/Table-Draw marker seen in the
//     data (Tray 1..16, Draw 1, Draw 2, Table 2 - Draw 1, ...)
//
// Chip lists for all three modes are computed FROM the loaded data (not
// hardcoded), so newly added branches/rooms/rows show up automatically
// without another code change here.
//
// Search matches on product name, category, branch, room, row, rack, and
// tray. Matching is partial (contains), case-insensitive, and whitespace
// insensitive (all whitespace is stripped before comparing, so "Row  2",
// "row2", and "ROW 2" all match the same query).
//
// Auto-seed is guarded exactly like every other module in this app
// (SeedGuardService, key 'products'): fires at most once per install,
// only when the collection is empty, and never retries silently. Manual
// re-seed lives behind an explicit confirmation dialog in the app bar menu.

import 'package:flutter/material.dart';

import 'package:cda_inventory/data/seed_branch1_products.dart';
import 'package:cda_inventory/data/seed_search_products.dart';
import 'package:cda_inventory/models/product.dart';
import 'package:cda_inventory/services/product_service.dart';
import 'package:cda_inventory/services/seed_guard_service.dart';

enum FilterMode { all, category, row, tray }

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => SearchScreenState();
}

class SearchScreenState extends State<SearchScreen> {
  // ── Design tokens (matches Search Products' established look: off-white
  //    page, white cards, dark navy app bar, solid-black selected chip). ──
  static const Color kNavy = Color(0xFF0A1628);
  static const Color kSurface = Color(0xFFF5F7FA);
  static const Color kChipSelected = Color(0xFF111318);
  static const Color kChipFill = Color(0xFFF0F1F3);
  static const Color kBorder = Color(0xFFE3E6EA);
  static const Color kTextSecondary = Color(0xFF6B7280);
  static const Color kGreen = Color(0xFF00B894);
  static const Color kAmber = Color(0xFFFFB800);
  static const Color kRed = Color(0xFFE5484D);
  static const Color kBlue = Color(0xFF1565C0);

  // ── Data state ────────────────────────────────────────────────────────
  List<Product> all = [];
  List<Product> filtered = [];
  bool isLoading = true;
  bool isSeeding = false;
  String? error;

  // ── Filter state ──────────────────────────────────────────────────────
  FilterMode mode = FilterMode.all;
  String? selectedValue; // selected category / row / tray, null = none
  String query = '';
  final TextEditingController searchController = TextEditingController();

  // In-memory guard so a re-seed check never fires more than once per
  // app session even if this screen is opened repeatedly (mirrors the
  // pattern in InventoryDashboard's branchMigrationDoneCache).
  static bool seedCheckedThisSession = false;

  @override
  void initState() {
    super.initState();
    load();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  // ── Firestore fetch ───────────────────────────────────────────────────
  // forceRefresh: false on initState (reuse ProductService's shared
  // cache if another screen already warmed it up this session). Pull-to-
  // refresh and the manual Refresh button always pass true.
  Future<void> load({bool forceRefresh = false}) async {
    setState(() {
      isLoading = true;
      error = null;
    });
    try {
      final products =
      await ProductService.getProducts(forceRefresh: forceRefresh);
      if (!mounted) return;
      setState(() {
        all = products;
        isLoading = false;
      });
      applyFilters();
      await autoSeedIfNeeded(products);
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = e.toString();
        isLoading = false;
      });
    }
  }

  // ── Guarded auto-seed ─────────────────────────────────────────────────
  // Only runs once per install (SeedGuardService key 'products'), and
  // only when the collection is genuinely empty. Seeds the general
  // catalogue (On Field / RPTO / etc.) plus the rebuilt Branch 1
  // (Adambakkam) inventory — the one with correct Row/Rack/Tray grouping
  // — so Search Products has real Row/Tray chips out of the box.
  Future<void> autoSeedIfNeeded(List<Product> existing) async {
    if (existing.isNotEmpty) return;
    if (seedCheckedThisSession) return;
    try {
      final alreadySeeded = await SeedGuardService.hasSeeded('products');
      if (alreadySeeded) {
        seedCheckedThisSession = true;
        return;
      }
      await runSeed();
      await SeedGuardService.markSeeded('products');
      seedCheckedThisSession = true;
    } catch (_) {
      // Best-effort — a failed auto-seed just means the screen shows
      // empty state; the manual "Seed Data" action can retry.
    }
  }

  Future<void> runSeed() async {
    setState(() => isSeeding = true);
    try {
      await ProductService.seedProducts(SeedSearchProducts.allItems);
      await ProductService.seedProducts(SeedBranch1Products.allItems);
      if (mounted) await load(forceRefresh: true);
    } finally {
      if (mounted) setState(() => isSeeding = false);
    }
  }

  Future<void> confirmManualSeed() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Re-seed Search Products?'),
        content: const Text(
          'This adds the full catalogue (On Field, RPTO, etc.) and the '
              'Branch 1 (Adambakkam) inventory — including Row/Rack/Tray '
              'locations — to the products collection. Existing items are '
              'left untouched; this only ever adds new documents.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: kNavy),
            child: const Text('Seed'),
          ),
        ],
      ),
    );
    if (confirmed == true) await runSeed();
  }

  // ── Derived chip lists (computed from loaded data, not hardcoded) ────
  List<String> get categories {
    final set = <String>{
      for (final p in all)
        if (p.category.trim().isNotEmpty) p.category.trim()
    };
    final list = set.toList()..sort();
    return list;
  }

  List<String> get rows {
    final set = <String>{
      for (final p in all)
        if ((p.row ?? '').trim().isNotEmpty) p.row!.trim()
    };
    final list = set.toList()..sort(_naturalCompare);
    return list;
  }

  List<String> get trays {
    final set = <String>{
      for (final p in all)
        if ((p.tray ?? '').trim().isNotEmpty) p.tray!.trim()
    };
    final list = set.toList()..sort(_naturalCompare);
    return list;
  }

  /// Sorts "Row 2" before "Row 10", "Tray 2" before "Tray 16", etc. by
  /// comparing any trailing number numerically instead of as text.
  int _naturalCompare(String a, String b) {
    final numA = RegExp(r'(\d+)$').firstMatch(a);
    final numB = RegExp(r'(\d+)$').firstMatch(b);
    if (numA != null && numB != null) {
      final prefixA = a.substring(0, numA.start);
      final prefixB = b.substring(0, numB.start);
      if (prefixA == prefixB) {
        return int.parse(numA.group(1)!).compareTo(int.parse(numB.group(1)!));
      }
    }
    return a.compareTo(b);
  }

  // ── Search normalization ─────────────────────────────────────────────
  // Case-insensitive AND whitespace-insensitive: all whitespace is
  // stripped (not just trimmed/collapsed) before comparing, so "Row 2",
  // "row2", "R o w 2", and "ROW   2" are all treated as equal for the
  // purposes of a partial match.
  String normalize(String? s) {
    if (s == null) return '';
    return s.toLowerCase().replaceAll(RegExp(r'\s+'), '');
  }

  // ── Apply filters locally (mode + selected value + free-text query) ──
  void applyFilters() {
    setState(() {
      final normalizedQuery = normalize(query);
      filtered = all.where((p) {
        final matchesMode = switch (mode) {
          FilterMode.all => true,
          FilterMode.category =>
          selectedValue == null || p.category.trim() == selectedValue,
          FilterMode.row =>
          selectedValue == null || (p.row ?? '').trim() == selectedValue,
          FilterMode.tray =>
          selectedValue == null || (p.tray ?? '').trim() == selectedValue,
        };
        if (!matchesMode) return false;
        if (normalizedQuery.isEmpty) return true;
        return normalize(p.name).contains(normalizedQuery) ||
            normalize(p.category).contains(normalizedQuery) ||
            normalize(p.branchName).contains(normalizedQuery) ||
            normalize(p.room).contains(normalizedQuery) ||
            normalize(p.row).contains(normalizedQuery) ||
            normalize(p.rack).contains(normalizedQuery) ||
            normalize(p.tray).contains(normalizedQuery) ||
            normalize(p.notes).contains(normalizedQuery);
      }).toList()
        ..sort((a, b) => a.name.compareTo(b.name));
    });
  }

  void selectMode(FilterMode newMode) {
    setState(() {
      mode = newMode;
      selectedValue = null;
    });
    applyFilters();
  }

  void selectValue(String? value) {
    setState(() => selectedValue = value);
    applyFilters();
  }

  void onSearchChanged(String value) {
    query = value;
    applyFilters();
  }

  // ═════════════════════════════════════════════════════════════════════
  //  BUILD
  // ═════════════════════════════════════════════════════════════════════
  @override
  Widget build(BuildContext context) {
    // Forced light theme for this whole screen. The app's ambient theme
    // defaults to dark (see ThemeProvider), and every card/surface here is
    // hardcoded white — any Text/Icon that didn't set an explicit color
    // (product names, stat values, quantity numbers, search hint) was
    // inheriting the dark theme's default WHITE text color and rendering
    // invisible on these white cards.
    return Theme(
      data: ThemeData.light().copyWith(
        scaffoldBackgroundColor: kSurface,
        textTheme: ThemeData.light().textTheme.apply(
          bodyColor: const Color(0xFF111318),
          displayColor: const Color(0xFF111318),
        ),
        iconTheme: const IconThemeData(color: Color(0xFF111318)),
      ),
      child: Scaffold(
        backgroundColor: kSurface,
        appBar: buildAppBar(),
        body: isLoading
            ? const Center(child: CircularProgressIndicator())
            : error != null
            ? buildError()
            : RefreshIndicator(
          onRefresh: () => load(forceRefresh: true),
          child: buildBody(),
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: kNavy,
          foregroundColor: Colors.white,
          icon: const Icon(Icons.add_rounded),
          label: const Text('Add Product'),
          onPressed: openAddSheet,
        ),
      ),
    );
  }

  PreferredSizeWidget buildAppBar() {
    return AppBar(
      title: const Text('Search Products'),
      backgroundColor: kNavy,
      foregroundColor: Colors.white,
      actions: [
        IconButton(
          icon: const Icon(Icons.refresh_rounded),
          tooltip: 'Refresh',
          onPressed: isSeeding ? null : () => load(forceRefresh: true),
        ),
        PopupMenuButton<String>(
          icon: const Icon(Icons.more_vert_rounded),
          onSelected: (v) {
            if (v == 'seed') confirmManualSeed();
          },
          itemBuilder: (ctx) => const [
            PopupMenuItem(
              value: 'seed',
              child: Row(
                children: [
                  Icon(Icons.cloud_upload_outlined, size: 18),
                  SizedBox(width: 10),
                  Text('Seed Data'),
                ],
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget buildError() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.cloud_off_rounded, size: 56, color: Colors.red.shade300),
            const SizedBox(height: 16),
            const Text('Failed to load products',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 8),
            Text(error!,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Colors.grey.shade500)),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: () => load(forceRefresh: true),
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Retry'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: kNavy, foregroundColor: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildBody() {
    if (isSeeding) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text('Seeding product catalogue…',
                style: TextStyle(color: kTextSecondary)),
          ],
        ),
      );
    }

    return CustomScrollView(
      physics: const AlwaysScrollableScrollPhysics(),
      slivers: [
        SliverToBoxAdapter(child: buildStatsStrip()),
        SliverToBoxAdapter(child: buildSearchBar()),
        SliverToBoxAdapter(child: buildModeSelector()),
        SliverToBoxAdapter(child: buildValueChips()),
        SliverToBoxAdapter(child: buildResultCountBadge()),
        all.isEmpty
            ? SliverFillRemaining(hasScrollBody: false,
            child: buildEmptyCollection())
            : filtered.isEmpty
            ? SliverFillRemaining(
            hasScrollBody: false, child: buildNoResults())
            : buildProductList(),
        const SliverToBoxAdapter(child: SizedBox(height: 96)),
      ],
    );
  }

  // ── Stats strip ───────────────────────────────────────────────────────
  Widget buildStatsStrip() {
    final total = all.length;
    final lowStock = all.where((p) => p.isLowStock).length;
    final outOfStock = all.where((p) => p.isOutOfStock).length;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Row(
        children: [
          Expanded(
              child: statCard('Total', '$total', Icons.inventory_2_outlined,
                  kBlue)),
          const SizedBox(width: 10),
          Expanded(
              child: statCard(
                  'Low Stock', '$lowStock', Icons.warning_amber_rounded,
                  kAmber)),
          const SizedBox(width: 10),
          Expanded(
              child: statCard(
                  'Out of Stock',
                  '$outOfStock',
                  Icons.remove_circle_outline,
                  kRed)),
        ],
      ),
    );
  }

  Widget statCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: kBorder),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: color),
          const SizedBox(height: 8),
          Text(value,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          Text(label,
              style: const TextStyle(fontSize: 11, color: kTextSecondary)),
        ],
      ),
    );
  }

  // ── Search bar ────────────────────────────────────────────────────────
  Widget buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
      child: TextField(
        controller: searchController,
        onChanged: onSearchChanged,
        decoration: InputDecoration(
          hintText: 'Search by name, category, branch, room, row, rack, or tray…',
          hintStyle: const TextStyle(fontSize: 13.5),
          prefixIcon: const Icon(Icons.search_rounded, size: 20),
          suffixIcon: query.isEmpty
              ? null
              : IconButton(
            icon: const Icon(Icons.close_rounded, size: 18),
            onPressed: () {
              searchController.clear();
              onSearchChanged('');
            },
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(vertical: 12),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: kBorder),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: kBorder),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: kNavy, width: 1.5),
          ),
        ),
      ),
    );
  }

  // ── Mode selector: All / Category / Row / Tray ────────────────────────
  Widget buildModeSelector() {
    Widget modeChip(String label, IconData icon, FilterMode targetMode) {
      final selected = mode == targetMode;
      return Padding(
        padding: const EdgeInsets.only(right: 8),
        child: ChoiceChip(
          avatar: Icon(icon,
              size: 15, color: selected ? Colors.white : kTextSecondary),
          label: Text(label),
          labelStyle: TextStyle(
            color: selected ? Colors.white : kTextSecondary,
            fontSize: 12.5,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
          ),
          selected: selected,
          onSelected: (_) => selectMode(targetMode),
          selectedColor: kChipSelected,
          backgroundColor: kChipFill,
          showCheckmark: false,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: BorderSide(color: selected ? kChipSelected : kBorder),
          ),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          visualDensity: VisualDensity.compact,
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            modeChip('All', Icons.apps_rounded, FilterMode.all),
            modeChip('By Category', Icons.category_outlined,
                FilterMode.category),
            modeChip('By Row', Icons.view_week_outlined, FilterMode.row),
            modeChip('By Tray', Icons.inbox_outlined, FilterMode.tray),
          ],
        ),
      ),
    );
  }

  // ── Value chips for the active mode (Category / Row / Tray lists) ─────
  Widget buildValueChips() {
    if (mode == FilterMode.all) return const SizedBox.shrink();

    final values = switch (mode) {
      FilterMode.category => categories,
      FilterMode.row => rows,
      FilterMode.tray => trays,
      FilterMode.all => <String>[],
    };

    if (values.isEmpty) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
        child: Text(
          mode == FilterMode.row
              ? 'No items have a Row assigned yet.'
              : mode == FilterMode.tray
              ? 'No items have a Tray assigned yet.'
              : 'No categories yet.',
          style: const TextStyle(color: kTextSecondary, fontSize: 12.5),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          valueChip('All', null, countFor(null)),
          ...values.map((v) => valueChip(v, v, countFor(v))),
        ],
      ),
    );
  }

  int countFor(String? value) {
    if (value == null) return all.length;
    return switch (mode) {
      FilterMode.category => all.where((p) => p.category.trim() == value).length,
      FilterMode.row => all.where((p) => (p.row ?? '').trim() == value).length,
      FilterMode.tray => all.where((p) => (p.tray ?? '').trim() == value).length,
      FilterMode.all => all.length,
    };
  }

  Widget valueChip(String label, String? value, int count) {
    final selected = selectedValue == value;
    return ChoiceChip(
      label: Text('$label · $count'),
      labelStyle: TextStyle(
        color: selected ? Colors.white : kTextSecondary,
        fontSize: 12,
        fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
      ),
      selected: selected,
      onSelected: (_) => selectValue(value),
      selectedColor: kChipSelected,
      backgroundColor: kChipFill,
      showCheckmark: false,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
        side: BorderSide(color: selected ? kChipSelected : kBorder),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      visualDensity: VisualDensity.compact,
    );
  }

  // ── Result count badge ────────────────────────────────────────────────
  Widget buildResultCountBadge() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(
              color: kBlue.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: kBlue.withValues(alpha: 0.2)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.inventory_2_outlined, size: 14, color: kBlue),
                const SizedBox(width: 6),
                Text(
                  '${filtered.length} of ${all.length} products',
                  style: const TextStyle(
                      fontWeight: FontWeight.w600, color: kBlue, fontSize: 12.5),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ── Product list ──────────────────────────────────────────────────────
  Widget buildProductList() {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
            (context, index) => Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
          child: ProductCard(
            product: filtered[index],
            onTap: () => openDetailSheet(filtered[index]),
          ),
        ),
        childCount: filtered.length,
      ),
    );
  }

  Widget buildEmptyCollection() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inventory_2_outlined,
                size: 56, color: Colors.grey.shade300),
            const SizedBox(height: 16),
            const Text('No products yet',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 8),
            const Text(
              'Seed the catalogue to get started, or add your first product.',
              textAlign: TextAlign.center,
              style: TextStyle(color: kTextSecondary, fontSize: 13),
            ),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: confirmManualSeed,
              icon: const Icon(Icons.cloud_upload_outlined),
              label: const Text('Seed Data'),
              style: ElevatedButton.styleFrom(
                  backgroundColor: kNavy, foregroundColor: Colors.white),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildNoResults() {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.search_off_rounded,
                size: 48, color: Colors.grey.shade300),
            const SizedBox(height: 12),
            const Text('No matching products',
                style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            const Text(
              'Try a different search term or clear the filter.',
              style: TextStyle(color: kTextSecondary, fontSize: 12.5),
            ),
            const SizedBox(height: 16),
            OutlinedButton.icon(
              onPressed: () {
                searchController.clear();
                query = '';
                selectMode(FilterMode.all);
              },
              icon: const Icon(Icons.clear_rounded, size: 18),
              label: const Text('Clear filters'),
            ),
          ],
        ),
      ),
    );
  }

  // ── Add / Edit / Delete ───────────────────────────────────────────────
  void openAddSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => ProductFormSheet(
        categories: categories,
        onSaved: () => load(forceRefresh: true),
      ),
    );
  }

  void openEditSheet(Product product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => ProductFormSheet(
        categories: categories,
        existing: product,
        onSaved: () => load(forceRefresh: true),
      ),
    );
  }

  void openDetailSheet(Product product) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (ctx) => ProductDetailSheet(
        product: product,
        onEdit: () {
          Navigator.pop(ctx);
          openEditSheet(product);
        },
        onDelete: () async {
          Navigator.pop(ctx);
          await confirmDelete(product);
        },
      ),
    );
  }

  Future<void> confirmDelete(Product product) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete product?'),
        content: Text('"${product.name}" will be permanently removed.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: kRed),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      await ProductService.deleteProduct(product.id);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('"${product.name}" deleted')),
        );
      }
      await load(forceRefresh: true);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Delete failed: $e')),
        );
      }
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  PRODUCT CARD — shows Product Name, Category, Quantity, Branch, Room,
//  Row, Rack, Tray as individual labeled pills so every requested field
//  is visible on the card without redesigning the card layout.
// ═══════════════════════════════════════════════════════════════════════
class ProductCard extends StatelessWidget {
  final Product product;
  final VoidCallback onTap;

  const ProductCard({
    required this.product,
    required this.onTap,
  });

  Color get stockColor {
    if (product.isOutOfStock) return const Color(0xFFE5484D);
    if (product.isLowStock) return const Color(0xFFFFB800);
    return const Color(0xFF00B894);
  }

  @override
  Widget build(BuildContext context) {
    final branch = (product.branchName ?? '').trim();
    final room = (product.room ?? '').trim();
    final row = (product.row ?? '').trim();
    final rack = (product.rack ?? '').trim();
    final tray = (product.tray ?? '').trim();

    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: const Color(0xFFE3E6EA)),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 4,
                height: 44,
                decoration: BoxDecoration(
                    color: stockColor, borderRadius: BorderRadius.circular(4)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                          fontWeight: FontWeight.w700, fontSize: 14.5),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 6,
                      runSpacing: 6,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        pill('Category', product.category,
                            const Color(0xFF1565C0)),
                        if (branch.isNotEmpty)
                          pill('Branch', branch, const Color(0xFF00897B)),
                        if (room.isNotEmpty)
                          pill('Room', room, const Color(0xFF8E24AA)),
                        if (row.isNotEmpty)
                          pill('Row', row, const Color(0xFF6C63FF)),
                        if (rack.isNotEmpty)
                          pill('Rack', rack, const Color(0xFFEF6C00)),
                        if (tray.isNotEmpty)
                          pill('Tray', tray, const Color(0xFF546E7A)),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    '${product.quantity}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w800, fontSize: 16),
                  ),
                  Text(
                    product.stockLabel,
                    style: TextStyle(
                        fontSize: 10.5,
                        color: stockColor,
                        fontWeight: FontWeight.w600),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget pill(String label, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        '$label: $text',
        style: TextStyle(
            fontSize: 10.5, color: color, fontWeight: FontWeight.w600),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  DETAIL SHEET — Product Name, Category, Quantity, Branch, Room, Row,
//  Rack, Tray each shown as their own row.
// ═══════════════════════════════════════════════════════════════════════
class ProductDetailSheet extends StatelessWidget {
  final Product product;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const ProductDetailSheet({
    required this.product,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final branch = (product.branchName ?? '').trim();
    final room = (product.room ?? '').trim();
    final rowValue = (product.row ?? '').trim();
    final rack = (product.rack ?? '').trim();
    final tray = (product.tray ?? '').trim();

    return Theme(
      data: ThemeData.light(),
      child: Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        ),
        padding: const EdgeInsets.fromLTRB(20, 14, 20, 24),
        child: SafeArea(
          top: false,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                      color: Colors.grey.shade300,
                      borderRadius: BorderRadius.circular(4)),
                ),
              ),
              Text(product.name,
                  style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0A1628))),
              const SizedBox(height: 12),
              row('Category', product.category),
              row('Quantity', '${product.quantity}  (${product.stockLabel})'),
              if (product.price > 0)
                row('Price', '₹${product.price.toStringAsFixed(2)}'),
              if (branch.isNotEmpty) row('Branch', branch),
              if (room.isNotEmpty) row('Room', room),
              if (rowValue.isNotEmpty) row('Row', rowValue),
              if (rack.isNotEmpty) row('Rack', rack),
              if (tray.isNotEmpty) row('Tray', tray),
              if ((product.notes ?? '').trim().isNotEmpty)
                row('Notes', product.notes!.trim()),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: onEdit,
                      icon: const Icon(Icons.edit_outlined, size: 18),
                      label: const Text('Edit'),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: onDelete,
                      icon: const Icon(Icons.delete_outline, size: 18),
                      label: const Text('Delete'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE5484D),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 12),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget row(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 84,
            child: Text(label,
                style: const TextStyle(color: Color(0xFF6B7280), fontSize: 12.5)),
          ),
          Expanded(
            child: Text(value,
                style: const TextStyle(
                    fontSize: 13.5,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF0A1628))),
          ),
        ],
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════
//  ADD / EDIT FORM SHEET
// ═══════════════════════════════════════════════════════════════════════
class ProductFormSheet extends StatefulWidget {
  final List<String> categories;
  final Product? existing; // null = add mode
  final VoidCallback onSaved;

  const ProductFormSheet({
    required this.categories,
    this.existing,
    required this.onSaved,
  });

  @override
  State<ProductFormSheet> createState() => ProductFormSheetState();
}

class ProductFormSheetState extends State<ProductFormSheet> {
  final formKey = GlobalKey<FormState>();
  late TextEditingController nameController;
  late TextEditingController categoryController;
  late TextEditingController qtyController;
  late TextEditingController priceController;
  late TextEditingController branchController;
  late TextEditingController roomController;
  late TextEditingController rowController;
  late TextEditingController rackController;
  late TextEditingController trayController;
  late TextEditingController notesController;
  bool saving = false;
  String? error;
  bool _autocompleteSynced = false;

  bool get isEdit => widget.existing != null;

  @override
  void initState() {
    super.initState();
    final p = widget.existing;
    nameController = TextEditingController(text: p?.name ?? '');
    categoryController = TextEditingController(text: p?.category ?? '');
    qtyController =
        TextEditingController(text: (p?.quantity ?? 1).toString());
    priceController = TextEditingController(
        text: (p?.price ?? 0.0) == 0.0 ? '' : p!.price.toString());
    branchController = TextEditingController(text: p?.branchName ?? '');
    roomController = TextEditingController(text: p?.room ?? '');
    rowController = TextEditingController(text: p?.row ?? '');
    rackController = TextEditingController(text: p?.rack ?? '');
    trayController = TextEditingController(text: p?.tray ?? '');
    notesController = TextEditingController(text: p?.notes ?? '');
  }

  @override
  void dispose() {
    nameController.dispose();
    categoryController.dispose();
    qtyController.dispose();
    priceController.dispose();
    branchController.dispose();
    roomController.dispose();
    rowController.dispose();
    rackController.dispose();
    trayController.dispose();
    notesController.dispose();
    super.dispose();
  }

  Future<void> save() async {
    if (!formKey.currentState!.validate()) return;
    setState(() {
      saving = true;
      error = null;
    });

    final data = <String, dynamic>{
      'name': nameController.text.trim(),
      'category': categoryController.text.trim(),
      'quantity': int.tryParse(qtyController.text.trim()) ?? 0,
      'price': double.tryParse(priceController.text.trim()) ?? 0.0,
      'notes': notesController.text.trim().isEmpty
          ? null
          : notesController.text.trim(),
      'branchName': branchController.text.trim().isEmpty
          ? null
          : branchController.text.trim(),
      'room': roomController.text.trim().isEmpty
          ? null
          : roomController.text.trim(),
      'row': rowController.text.trim().isEmpty ? null : rowController.text.trim(),
      'rack':
      rackController.text.trim().isEmpty ? null : rackController.text.trim(),
      'tray':
      trayController.text.trim().isEmpty ? null : trayController.text.trim(),
    };

    try {
      if (isEdit) {
        await ProductService.updateProduct(widget.existing!.id, data);
      } else {
        await ProductService.addProduct(data);
      }
      if (mounted) {
        Navigator.pop(context);
        widget.onSaved();
      }
    } catch (e) {
      setState(() {
        error = e.toString().replaceFirst('Exception: ', '');
        saving = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final viewInsets = MediaQuery.of(context).viewInsets;

    // Forced light theme for this subtree — the ambient app theme may be
    // dark (see ThemeProvider), and this sheet's background is hardcoded
    // white, so labels/borders need to stay dark regardless of app theme.
    return Theme(
      data: ThemeData.light().copyWith(
        inputDecorationTheme: const InputDecorationTheme(
          labelStyle: TextStyle(color: Colors.black87),
          hintStyle: TextStyle(color: Colors.black45),
          floatingLabelStyle: TextStyle(color: Colors.black87),
          border:
          OutlineInputBorder(borderSide: BorderSide(color: Colors.grey)),
          enabledBorder:
          OutlineInputBorder(borderSide: BorderSide(color: Colors.grey)),
          focusedBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Color(0xFF0A1628), width: 2)),
        ),
      ),
      child: AnimatedPadding(
        padding: viewInsets,
        duration: const Duration(milliseconds: 150),
        child: Container(
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 20),
          child: SafeArea(
            top: false,
            child: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Center(
                      child: Container(
                        width: 40,
                        height: 4,
                        margin: const EdgeInsets.only(bottom: 14),
                        decoration: BoxDecoration(
                            color: Colors.grey.shade300,
                            borderRadius: BorderRadius.circular(4)),
                      ),
                    ),
                    Text(
                      isEdit ? 'Edit Product' : 'Add Product',
                      style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF0A1628)),
                    ),
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: nameController,
                      decoration: const InputDecoration(
                          labelText: 'Product name',
                          border: OutlineInputBorder()),
                      validator: (v) =>
                      (v == null || v.trim().isEmpty) ? 'Name is required' : null,
                    ),
                    const SizedBox(height: 12),
                    Autocomplete<String>(
                      initialValue: TextEditingValue(
                          text: categoryController.text),
                      optionsBuilder: (v) {
                        if (v.text.isEmpty) return widget.categories;
                        return widget.categories
                            .where((c) => c.toLowerCase().contains(v.text.toLowerCase()));
                      },
                      onSelected: (v) => categoryController.text = v,
                      fieldViewBuilder: (ctx, controller, focusNode, onSubmit) {
                        // Sync Autocomplete's internal controller with our
                        // own (once — repeated fieldViewBuilder rebuilds
                        // must not stack listeners) so free-typed (new)
                        // categories save too.
                        if (!_autocompleteSynced) {
                          _autocompleteSynced = true;
                          controller.text = categoryController.text;
                          controller.addListener(
                                  () => categoryController.text = controller.text);
                        }
                        return TextFormField(
                          controller: controller,
                          focusNode: focusNode,
                          decoration: const InputDecoration(
                            labelText: 'Category',
                            hintText: 'Pick existing or type a new one',
                            border: OutlineInputBorder(),
                          ),
                          validator: (v) => (v == null || v.trim().isEmpty)
                              ? 'Category is required'
                              : null,
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: qtyController,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                                labelText: 'Quantity',
                                border: OutlineInputBorder()),
                            validator: (v) {
                              final n = int.tryParse(v?.trim() ?? '');
                              if (n == null || n < 0) return 'Invalid';
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextFormField(
                            controller: priceController,
                            keyboardType:
                            const TextInputType.numberWithOptions(
                                decimal: true),
                            decoration: const InputDecoration(
                              labelText: 'Price (optional)',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text('Physical location (optional)',
                          style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 12.5,
                              color: Colors.black54)),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: branchController,
                            decoration: const InputDecoration(
                                labelText: 'Branch',
                                hintText: 'e.g. CDA Ops',
                                border: OutlineInputBorder()),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: roomController,
                            decoration: const InputDecoration(
                                labelText: 'Room',
                                hintText: 'e.g. Lab Room',
                                border: OutlineInputBorder()),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: rowController,
                            decoration: const InputDecoration(
                                labelText: 'Row',
                                hintText: 'e.g. Row 2',
                                border: OutlineInputBorder()),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: rackController,
                            decoration: const InputDecoration(
                                labelText: 'Rack',
                                hintText: 'e.g. Shelf 1',
                                border: OutlineInputBorder()),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: trayController,
                      decoration: const InputDecoration(
                          labelText: 'Tray',
                          hintText: 'e.g. Tray 4, Draw 1',
                          border: OutlineInputBorder()),
                    ),
                    const SizedBox(height: 12),
                    TextFormField(
                      controller: notesController,
                      maxLines: 2,
                      decoration: const InputDecoration(
                          labelText: 'Notes (optional)',
                          border: OutlineInputBorder()),
                    ),
                    if (error != null) ...[
                      const SizedBox(height: 12),
                      Text(error!,
                          style: const TextStyle(
                              color: Colors.red, fontSize: 13)),
                    ],
                    const SizedBox(height: 20),
                    SizedBox(
                      height: 48,
                      child: ElevatedButton(
                        onPressed: saving ? null : save,
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF0A1628),
                          foregroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12)),
                        ),
                        child: saving
                            ? const SizedBox(
                          width: 22,
                          height: 22,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white),
                        )
                            : Text(isEdit ? 'Save Changes' : 'Add Product'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
