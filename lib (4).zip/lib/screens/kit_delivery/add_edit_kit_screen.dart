// lib/screens/kit_delivery/add_edit_kit_screen.dart
//
// Create or edit a kit delivery. The parts list starts from the default kit
// (drone, propellers, motors, battery, charger, controller, bag). For each
// part enter how many the customer is OWED and how many are handed over
// TODAY — whatever is left is "pending" and will trigger the reminder on
// the promised date.

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../constants/drone_categories.dart';
import '../../constants/kit_templates.dart';
import '../../models/customer_details.dart';
import '../../models/kit_delivery.dart';
import '../../services/current_user_service.dart';
import '../../services/customer_service.dart';
import '../../services/kit_delivery_service.dart';
import 'kit_dashboard_screen.dart'
    show kKitBg, kKitNavy, kKitBlue, kKitRed, kKitMuted, kKitBorder, kKitGreen;

class _ItemDraft {
  final TextEditingController name;
  String category;
  int required;
  int delivered;

  _ItemDraft({
    required String name,
    required this.category,
    required this.required,
    required this.delivered,
  }) : name = TextEditingController(text: name);

  int get pending {
    final p = required - delivered;
    return p < 0 ? 0 : p;
  }

  void dispose() => name.dispose();
}

class AddEditKitScreen extends StatefulWidget {
  /// Null = new kit.
  final KitDelivery? kit;

  const AddEditKitScreen({super.key, this.kit});

  @override
  State<AddEditKitScreen> createState() => _AddEditKitScreenState();
}

class _AddEditKitScreenState extends State<AddEditKitScreen> {
  final _formKey = GlobalKey<FormState>();
  final KitDeliveryService _service = KitDeliveryService();

  final _customer = TextEditingController();
  final _phone = TextEditingController();
  final _address = TextEditingController();
  final _invoice = TextEditingController();
  final _notes = TextEditingController();

  String _branch = kBranchOptions.first;
  DateTime _deliveredAt = DateTime.now();
  DateTime? _promisedDate;
  bool _promisedTouched = false;

  final List<_ItemDraft> _items = [];
  List<CustomerDetails> _customers = [];

  bool _saving = false;

  bool get _isEdit => widget.kit != null;

  @override
  void initState() {
    super.initState();

    final k = widget.kit;
    if (k != null) {
      _customer.text = k.customerName;
      _phone.text = k.customerPhone;
      _address.text = k.customerAddress;
      _invoice.text = k.invoiceRef;
      _notes.text = k.notes;
      _branch = k.branch;
      _deliveredAt = k.deliveredAt;
      _promisedDate = k.promisedDate;
      _promisedTouched = true;
      for (final i in k.items) {
        _items.add(_ItemDraft(
          name: i.name,
          category: i.category,
          required: i.requiredQty,
          delivered: i.deliveredQty,
        ));
      }
    } else {
      // Start with the full kit; the user lowers "given today" for
      // whatever is not handed over.
      for (final m in kDefaultKitItems) {
        final qty = m['qty'] as int;
        _items.add(_ItemDraft(
          name: m['name'] as String,
          category: m['category'] as String,
          required: qty,
          delivered: qty,
        ));
      }
    }

    _loadCustomers();
  }

  @override
  void dispose() {
    _customer.dispose();
    _phone.dispose();
    _address.dispose();
    _invoice.dispose();
    _notes.dispose();
    for (final i in _items) {
      i.dispose();
    }
    super.dispose();
  }

  Future<void> _loadCustomers() async {
    // Convenience only — employees without access to Customers simply get
    // no suggestions.
    try {
      final list = await CustomerService().fetchCustomers();
      if (mounted) setState(() => _customers = list);
    } catch (_) {}
  }

  bool get _hasPending => _items.any((i) => i.pending > 0);

  // Promised date defaults to "delivery date + N days" until the user picks
  // one themselves.
  void _syncDefaultPromised() {
    if (_promisedTouched) return;
    _promisedDate = _hasPending
        ? KitDeliveryService.defaultPromisedDate(_deliveredAt)
        : null;
  }

  Future<DateTime?> _pickDate(DateTime initial,
      {DateTime? first, DateTime? last}) {
    return showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: first ?? DateTime(2020),
      lastDate: last ?? DateTime(2100),
    );
  }

  void _addPart() {
    setState(() {
      _items.add(_ItemDraft(
        name: '',
        category: 'Other',
        required: 1,
        delivered: 0,
      ));
      _syncDefaultPromised();
    });
  }

  void _removePart(int index) {
    setState(() {
      _items.removeAt(index).dispose();
      _syncDefaultPromised();
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    if (_items.isEmpty) {
      _snack('Add at least one part to the kit.');
      return;
    }

    // Duplicate part names would make "hand over" ambiguous.
    final names = _items.map((i) => i.name.text.trim().toLowerCase()).toList();
    if (names.toSet().length != names.length) {
      _snack('Two parts have the same name. Rename or remove one.');
      return;
    }

    if (_hasPending && _promisedDate == null) {
      _snack('Pick the date the pending parts are promised for.');
      return;
    }

    setState(() => _saving = true);

    final items = _items
        .map((i) => KitItem(
      name: i.name.text.trim(),
      category: i.category,
      requiredQty: i.required,
      deliveredQty: i.delivered > i.required ? i.required : i.delivered,
    ))
        .toList();

    KitResult<KitDelivery> result;

    if (_isEdit) {
      final before = widget.kit!;
      final after = before.copyWith(
        customerName: _customer.text.trim(),
        customerPhone: _phone.text.trim(),
        customerAddress: _address.text.trim(),
        branch: _branch,
        invoiceRef: _invoice.text.trim(),
        deliveredAt: _deliveredAt,
        promisedDate: _promisedDate,
        items: items,
        notes: _notes.text.trim(),
      );
      result = await _service.updateKit(before, after);
    } else {
      // Record what was handed over on the first day as the first line of
      // the hand-over history.
      final today = <String, int>{
        for (final i in items)
          if (i.deliveredQty > 0) i.name: i.deliveredQty,
      };
      final who = await CurrentUserService.getName();

      final kit = KitDelivery(
        id: '',
        customerName: _customer.text.trim(),
        customerPhone: _phone.text.trim(),
        customerAddress: _address.text.trim(),
        branch: _branch,
        invoiceRef: _invoice.text.trim(),
        deliveredAt: _deliveredAt,
        promisedDate: _promisedDate,
        items: items,
        handovers: today.isEmpty
            ? const []
            : [
          KitHandover(
            at: _deliveredAt,
            by: who,
            note: 'Initial delivery',
            quantities: today,
          ),
        ],
        notes: _notes.text.trim(),
      );
      // A kit that is complete on day one has nothing to remind about.
      result = await _service.addKit(
        kit.isComplete ? kit.copyWith(completedAt: DateTime.now()) : kit,
      );
    }

    if (!mounted) return;
    setState(() => _saving = false);

    if (result.success) {
      Navigator.pop(context, true);
    } else {
      _snack(result.error ?? 'Could not save the kit.');
    }
  }

  void _snack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating),
    );
  }

  InputDecoration _dec(String label, {IconData? icon}) => InputDecoration(
    labelText: label,
    prefixIcon: icon == null ? null : Icon(icon, size: 20),
    filled: true,
    fillColor: Colors.white,
    isDense: true,
    border: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: kKitBorder),
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: kKitBorder),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('dd MMM yyyy');

    return Scaffold(
      backgroundColor: kKitBg,
      appBar: AppBar(
        backgroundColor: kKitNavy,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Text(
          _isEdit ? 'Edit Kit' : 'New Kit Delivery',
          style: const TextStyle(
              color: Colors.white, fontWeight: FontWeight.w800),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 120),
          children: [
            // ── Customer ──────────────────────────────────────────────
            const _SectionTitle('Customer'),
            Autocomplete<CustomerDetails>(
              displayStringForOption: (c) => c.name,
              optionsBuilder: (v) {
                final q = v.text.trim().toLowerCase();
                if (q.isEmpty) return const Iterable<CustomerDetails>.empty();
                return _customers
                    .where((c) =>
                c.nameKey.contains(q) || c.phoneKey.contains(q))
                    .take(6);
              },
              onSelected: (c) {
                _customer.text = c.name;
                if ((c.phone ?? '').isNotEmpty) _phone.text = c.phone!;
                if ((c.shippingAddress ?? c.billingAddress ?? '')
                    .isNotEmpty) {
                  _address.text = c.shippingAddress?.isNotEmpty == true
                      ? c.shippingAddress!
                      : c.billingAddress!;
                }
              },
              // Pre-fills the field when editing an existing kit.
              initialValue: TextEditingValue(text: _customer.text),
              fieldViewBuilder: (context, controller, focus, onSubmit) {
                return TextFormField(
                  controller: controller,
                  focusNode: focus,
                  // _customer mirrors what is typed so _save() can read it.
                  onChanged: (v) => _customer.text = v,
                  textCapitalization: TextCapitalization.words,
                  decoration: _dec('Customer name *', icon: Icons.person),
                  validator: (v) => (v == null || v.trim().isEmpty)
                      ? 'Enter the customer name'
                      : null,
                );
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _phone,
              keyboardType: TextInputType.phone,
              decoration: _dec('Phone', icon: Icons.phone),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _address,
              maxLines: 2,
              decoration: _dec('Address', icon: Icons.location_on_outlined),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: _branch,
                    decoration: _dec('Branch'),
                    items: [
                      for (final b in kBranchOptions)
                        DropdownMenuItem(
                          value: b,
                          child: Text(kBranchLabels[b] ?? b),
                        ),
                    ],
                    onChanged: (v) => setState(() => _branch = v ?? _branch),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: TextFormField(
                    controller: _invoice,
                    decoration: _dec('Invoice / challan no.'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            InkWell(
              onTap: () async {
                final d = await _pickDate(_deliveredAt,
                    last: DateTime.now().add(const Duration(days: 1)));
                if (d != null) {
                  setState(() {
                    _deliveredAt = d;
                    _syncDefaultPromised();
                  });
                }
              },
              child: InputDecorator(
                decoration: _dec('Delivery date', icon: Icons.event),
                child: Text(fmt.format(_deliveredAt)),
              ),
            ),

            // ── Parts ─────────────────────────────────────────────────
            const SizedBox(height: 22),
            Row(
              children: [
                const Expanded(child: _SectionTitle('Kit parts')),
                TextButton.icon(
                  onPressed: _addPart,
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Add part'),
                ),
              ],
            ),
            const Padding(
              padding: EdgeInsets.only(bottom: 8),
              child: Text(
                'For each part: how many the customer should get, and how '
                    'many are handed over now. Anything not handed over is '
                    'marked pending and will remind you.',
                style: TextStyle(color: kKitMuted, fontSize: 12),
              ),
            ),
            for (int i = 0; i < _items.length; i++)
              _PartRow(
                key: ObjectKey(_items[i]),
                draft: _items[i],
                onChanged: () => setState(_syncDefaultPromised),
                onRemove: () => _removePart(i),
              ),

            // ── Pending / reminder ────────────────────────────────────
            const SizedBox(height: 18),
            _PendingBanner(items: _items),
            if (_hasPending) ...[
              const SizedBox(height: 12),
              InkWell(
                onTap: () async {
                  final d = await _pickDate(
                    _promisedDate ?? DateTime.now(),
                    first: DateTime.now().subtract(const Duration(days: 365)),
                  );
                  if (d != null) {
                    setState(() {
                      _promisedDate = d;
                      _promisedTouched = true;
                    });
                  }
                },
                child: InputDecorator(
                  decoration: _dec('Pending parts promised by *',
                      icon: Icons.notifications_active_outlined),
                  child: Text(
                    _promisedDate == null
                        ? 'Pick a date'
                        : '${fmt.format(_promisedDate!)}  '
                        '(reminder at ${kKitReminderHour.toString().padLeft(2, '0')}:'
                        '${kKitReminderMinute.toString().padLeft(2, '0')}, repeats daily)',
                  ),
                ),
              ),
            ],

            const SizedBox(height: 12),
            TextFormField(
              controller: _notes,
              maxLines: 3,
              decoration: _dec('Notes', icon: Icons.notes),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
          child: SizedBox(
            height: 50,
            child: ElevatedButton.icon(
              onPressed: _saving ? null : _save,
              style: ElevatedButton.styleFrom(
                backgroundColor: kKitBlue,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14)),
              ),
              icon: _saving
                  ? const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(
                    strokeWidth: 2, color: Colors.white),
              )
                  : const Icon(Icons.check),
              label: Text(_isEdit ? 'Save changes' : 'Save kit'),
            ),
          ),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: Text(
      text,
      style: const TextStyle(
        color: kKitNavy,
        fontWeight: FontWeight.w800,
        fontSize: 15,
      ),
    ),
  );
}

class _PendingBanner extends StatelessWidget {
  final List<_ItemDraft> items;
  const _PendingBanner({required this.items});

  @override
  Widget build(BuildContext context) {
    final pending = items.where((i) => i.pending > 0).toList();
    final ok = pending.isEmpty;
    final color = ok ? kKitGreen : kKitRed;

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(ok ? Icons.check_circle : Icons.pending_actions, color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              ok
                  ? 'Complete kit — nothing pending.'
                  : 'Pending: ${pending.map((i) => '${i.name.text.trim().isEmpty ? 'Unnamed part' : i.name.text.trim()} ×${i.pending}').join(', ')}',
              style: TextStyle(color: color, fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

class _PartRow extends StatelessWidget {
  final _ItemDraft draft;
  final VoidCallback onChanged;
  final VoidCallback onRemove;

  const _PartRow({
    super.key,
    required this.draft,
    required this.onChanged,
    required this.onRemove,
  });

  Widget _stepper({
    required String label,
    required int value,
    required int min,
    required int max,
    required ValueChanged<int> onValue,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: kKitMuted, fontSize: 11)),
        const SizedBox(height: 2),
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            _RoundBtn(
              icon: Icons.remove,
              onTap: value > min ? () => onValue(value - 1) : null,
            ),
            SizedBox(
              width: 34,
              child: Text(
                '$value',
                textAlign: TextAlign.center,
                style: const TextStyle(
                    fontWeight: FontWeight.w800, fontSize: 15),
              ),
            ),
            _RoundBtn(
              icon: Icons.add,
              onTap: value < max ? () => onValue(value + 1) : null,
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: draft.pending > 0 ? kKitRed.withOpacity(0.35) : kKitBorder,
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: draft.name,
                  textCapitalization: TextCapitalization.words,
                  decoration: const InputDecoration(
                    isDense: true,
                    hintText: 'Part name (e.g. Propellers)',
                    border: InputBorder.none,
                  ),
                  style: const TextStyle(fontWeight: FontWeight.w700),
                  onChanged: (_) => onChanged(),
                  validator: (v) => (v == null || v.trim().isEmpty)
                      ? 'Enter a part name'
                      : null,
                ),
              ),
              IconButton(
                tooltip: 'Remove part',
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.close, size: 18, color: kKitMuted),
                onPressed: onRemove,
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _stepper(
                label: 'Customer should get',
                value: draft.required,
                min: 1,
                max: 999,
                onValue: (v) {
                  draft.required = v;
                  if (draft.delivered > v) draft.delivered = v;
                  onChanged();
                },
              ),
              _stepper(
                label: 'Handed over now',
                value: draft.delivered,
                min: 0,
                max: draft.required,
                onValue: (v) {
                  draft.delivered = v;
                  onChanged();
                },
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  const Text('Pending',
                      style: TextStyle(color: kKitMuted, fontSize: 11)),
                  const SizedBox(height: 6),
                  Text(
                    '${draft.pending}',
                    style: TextStyle(
                      color: draft.pending > 0 ? kKitRed : kKitGreen,
                      fontWeight: FontWeight.w800,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _RoundBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  const _RoundBtn({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      customBorder: const CircleBorder(),
      onTap: onTap,
      child: Container(
        width: 28,
        height: 28,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: onTap == null ? Colors.grey.shade200 : kKitBlue.withOpacity(0.12),
        ),
        child: Icon(icon,
            size: 16, color: onTap == null ? Colors.grey : kKitBlue),
      ),
    );
  }
}