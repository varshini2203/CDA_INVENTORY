// lib/screens/kit_delivery/kit_dashboard_screen.dart
//
// "Kit Deliveries" home screen: every drone kit handed to a customer, with
// the parts that are still PENDING (propellers, bag, drone ...) highlighted.
// The dashboard bell opens this screen with the "Due / Overdue" filter.
//
// Filters: Due / Overdue · Pending · Completed · All, plus branch + search.

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../constants/drone_categories.dart';
import '../../models/kit_delivery.dart';
import '../../services/kit_delivery_service.dart';
import 'add_edit_kit_screen.dart';
import 'kit_detail_screen.dart';

// Same light palette as the main dashboard.
const Color kKitBg = Color(0xFFF4F7FC);
const Color kKitNavy = Color(0xFF0F1E3A);
const Color kKitBlue = Color(0xFF1E5FC8);
const Color kKitGreen = Color(0xFF00A870);
const Color kKitRed = Color(0xFFE8374A);
const Color kKitAmber = Color(0xFFD99A00);
const Color kKitMuted = Color(0xFF7A8CA8);
const Color kKitBorder = Color(0xFFD5DFEE);

enum KitFilter { due, pending, completed, all }

extension KitFilterLabel on KitFilter {
  String get label {
    switch (this) {
      case KitFilter.due:
        return 'Due / Overdue';
      case KitFilter.pending:
        return 'Pending';
      case KitFilter.completed:
        return 'Completed';
      case KitFilter.all:
        return 'All';
    }
  }
}

/// Human text for a kit's promised date: "Overdue 3d", "Due today",
/// "Due in 2d", "No date".
String kitDueText(KitDelivery k) {
  if (k.isComplete) return 'Completed';
  if (k.promisedDate == null) return 'No promised date';
  if (k.isOverdue) return 'Overdue ${k.daysOverdue}d';
  final p = k.promisedDate!;
  final now = DateTime.now();
  final days = DateTime(p.year, p.month, p.day)
      .difference(DateTime(now.year, now.month, now.day))
      .inDays;
  return days == 0 ? 'Due today' : 'Due in ${days}d';
}

Color kitDueColor(KitDelivery k) {
  if (k.isComplete) return kKitGreen;
  if (k.isOverdue) return kKitRed;
  if (k.isDueOrOverdue) return kKitAmber;
  return kKitBlue;
}

class KitDashboardScreen extends StatefulWidget {
  final KitFilter initialFilter;

  const KitDashboardScreen({
    super.key,
    this.initialFilter = KitFilter.pending,
  });

  @override
  State<KitDashboardScreen> createState() => _KitDashboardScreenState();
}

class _KitDashboardScreenState extends State<KitDashboardScreen> {
  final KitDeliveryService _service = KitDeliveryService();

  // Created once — creating it inside build() would re-open the Firestore
  // listener on every rebuild.
  late final Stream<List<KitDelivery>> _stream =
  _service.kitsStreamWithReminderSync();

  late KitFilter _filter = widget.initialFilter;
  String _branch = KitDeliveryService.branchAll;
  String _query = '';
  Timer? _tick;

  @override
  void initState() {
    super.initState();
    // Refresh "Overdue 3d" / "Due today" labels when midnight passes.
    _tick = Timer.periodic(const Duration(minutes: 5), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    _tick?.cancel();
    super.dispose();
  }

  List<KitDelivery> _apply(List<KitDelivery> all) {
    Iterable<KitDelivery> list = all;

    if (_branch != KitDeliveryService.branchAll) {
      list = list.where((k) => k.branch == _branch);
    }

    switch (_filter) {
      case KitFilter.due:
        list = list.where((k) => k.isDueOrOverdue);
        break;
      case KitFilter.pending:
        list = list.where((k) => k.isPending);
        break;
      case KitFilter.completed:
        list = list.where((k) => k.isComplete);
        break;
      case KitFilter.all:
        break;
    }

    final q = _query.trim().toLowerCase();
    if (q.isNotEmpty) {
      list = list.where((k) =>
      k.customerName.toLowerCase().contains(q) ||
          k.customerPhone.contains(q) ||
          k.invoiceRef.toLowerCase().contains(q) ||
          k.items.any((i) => i.name.toLowerCase().contains(q)));
    }

    final out = list.toList();
    if (_filter == KitFilter.completed || _filter == KitFilter.all) {
      out.sort((a, b) => b.deliveredAt.compareTo(a.deliveredAt));
    } else {
      // Most urgent first; kits without a date last.
      out.sort((a, b) {
        final ap = a.promisedDate;
        final bp = b.promisedDate;
        if (ap == null && bp == null) return 0;
        if (ap == null) return 1;
        if (bp == null) return -1;
        return ap.compareTo(bp);
      });
    }
    return out;
  }

  Future<void> _openAdd() async {
    await Navigator.push(
      context,
      MaterialPageRoute(
        settings: const RouteSettings(name: 'Add Kit'),
        builder: (_) => const AddEditKitScreen(),
      ),
    );
  }

  void _openDetail(KitDelivery k) {
    Navigator.push(
      context,
      MaterialPageRoute(
        settings: const RouteSettings(name: 'Kit Details'),
        builder: (_) => KitDetailScreen(kitId: k.id),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kKitBg,
      appBar: AppBar(
        backgroundColor: kKitNavy,
        iconTheme: const IconThemeData(color: Colors.white),
        title: const Text(
          'Kit Deliveries',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: kKitBlue,
        foregroundColor: Colors.white,
        onPressed: _openAdd,
        icon: const Icon(Icons.add),
        label: const Text('New Kit'),
      ),
      body: StreamBuilder<List<KitDelivery>>(
        stream: _stream,
        builder: (context, snap) {
          if (snap.hasError) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Text(
                  'Could not load kits.\n${snap.error}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: kKitRed),
                ),
              ),
            );
          }
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }

          final all = snap.data!;
          final scoped = _branch == KitDeliveryService.branchAll
              ? all
              : all.where((k) => k.branch == _branch).toList();

          final pendingKits = scoped.where((k) => k.isPending).toList();
          final dueKits = scoped.where((k) => k.isDueOrOverdue).toList();
          final partsPending =
          pendingKits.fold<int>(0, (a, k) => a + k.totalPending);

          final shown = _apply(all);

          return Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 760),
              child: Column(
                children: [
                  _SummaryRow(
                    pending: pendingKits.length,
                    due: dueKits.length,
                    parts: partsPending,
                  ),
                  _FilterBar(
                    filter: _filter,
                    branch: _branch,
                    dueCount: dueKits.length,
                    onFilter: (f) => setState(() => _filter = f),
                    onBranch: (b) => setState(() => _branch = b),
                    onSearch: (q) => setState(() => _query = q),
                  ),
                  Expanded(
                    child: shown.isEmpty
                        ? _EmptyState(filter: _filter)
                        : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
                      itemCount: shown.length,
                      separatorBuilder: (_, __) =>
                      const SizedBox(height: 12),
                      itemBuilder: (_, i) => _KitCard(
                        kit: shown[i],
                        onTap: () => _openDetail(shown[i]),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _SummaryRow extends StatelessWidget {
  final int pending;
  final int due;
  final int parts;

  const _SummaryRow({
    required this.pending,
    required this.due,
    required this.parts,
  });

  @override
  Widget build(BuildContext context) {
    Widget tile(String label, int value, Color c, IconData icon) => Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: kKitBorder),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(7),
              decoration: BoxDecoration(
                color: c.withOpacity(0.12),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Icon(icon, color: c, size: 18),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('$value',
                      style: TextStyle(
                          color: c,
                          fontSize: 20,
                          fontWeight: FontWeight.w800)),
                  Text(label,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style:
                      const TextStyle(color: kKitMuted, fontSize: 11)),
                ],
              ),
            ),
          ],
        ),
      ),
    );

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 6),
      child: Row(
        children: [
          tile('Kits pending', pending, kKitAmber, Icons.inventory_2_outlined),
          const SizedBox(width: 10),
          tile('Due / overdue', due, kKitRed, Icons.notifications_active),
          const SizedBox(width: 10),
          tile('Parts to give', parts, kKitBlue, Icons.extension_outlined),
        ],
      ),
    );
  }
}

class _FilterBar extends StatelessWidget {
  final KitFilter filter;
  final String branch;
  final int dueCount;
  final ValueChanged<KitFilter> onFilter;
  final ValueChanged<String> onBranch;
  final ValueChanged<String> onSearch;

  const _FilterBar({
    required this.filter,
    required this.branch,
    required this.dueCount,
    required this.onFilter,
    required this.onBranch,
    required this.onSearch,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 6),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: TextField(
                  onChanged: onSearch,
                  decoration: InputDecoration(
                    isDense: true,
                    hintText: 'Search customer, phone, invoice, part…',
                    prefixIcon: const Icon(Icons.search, size: 20),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: kKitBorder),
                    ),
                    enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: const BorderSide(color: kKitBorder),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: kKitBorder),
                ),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                    value: branch,
                    items: [
                      const DropdownMenuItem(
                        value: KitDeliveryService.branchAll,
                        child: Text('All Branch'),
                      ),
                      for (final b in kBranchOptions)
                        DropdownMenuItem(
                          value: b,
                          child: Text(kBranchLabels[b] ?? b),
                        ),
                    ],
                    onChanged: (v) {
                      if (v != null) onBranch(v);
                    },
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                for (final f in KitFilter.values)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      selected: filter == f,
                      onSelected: (_) => onFilter(f),
                      selectedColor: kKitBlue,
                      backgroundColor: Colors.white,
                      side: const BorderSide(color: kKitBorder),
                      labelStyle: TextStyle(
                        color: filter == f ? Colors.white : kKitNavy,
                        fontWeight: FontWeight.w700,
                        fontSize: 12,
                      ),
                      label: Text(
                        f == KitFilter.due && dueCount > 0
                            ? '${f.label} ($dueCount)'
                            : f.label,
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  final KitFilter filter;
  const _EmptyState({required this.filter});

  @override
  Widget build(BuildContext context) {
    final text = {
      KitFilter.due: 'Nothing due right now',
      KitFilter.pending: 'No kits with pending parts',
      KitFilter.completed: 'No completed kits yet',
      KitFilter.all: 'No kits yet — tap "New Kit" to add one',
    }[filter]!;

    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.inventory_2_outlined,
              size: 48, color: Colors.grey.shade400),
          const SizedBox(height: 10),
          Text(text, style: TextStyle(color: Colors.grey.shade600)),
        ],
      ),
    );
  }
}

class _KitCard extends StatelessWidget {
  final KitDelivery kit;
  final VoidCallback onTap;

  const _KitCard({required this.kit, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final dueColor = kitDueColor(kit);
    final fmt = DateFormat('dd MMM yyyy');

    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: kit.isDueOrOverdue
                ? dueColor.withOpacity(0.5)
                : kKitBorder,
          ),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        kit.customerName,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: kKitNavy,
                          fontWeight: FontWeight.w800,
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        [
                          kBranchLabels[kit.branch] ?? kit.branch,
                          if (kit.invoiceRef.isNotEmpty) kit.invoiceRef,
                          'Delivered ${fmt.format(kit.deliveredAt)}',
                        ].join(' · '),
                        style:
                        const TextStyle(color: kKitMuted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                Container(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: dueColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    kitDueText(kit),
                    style: TextStyle(
                      color: dueColor,
                      fontWeight: FontWeight.w800,
                      fontSize: 11,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: kit.progress,
                minHeight: 6,
                backgroundColor: kKitBorder,
                valueColor: AlwaysStoppedAnimation(
                  kit.isComplete ? kKitGreen : kKitBlue,
                ),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${kit.totalDelivered} of ${kit.totalRequired} parts delivered',
              style: const TextStyle(color: kKitMuted, fontSize: 11),
            ),
            if (kit.isPending) ...[
              const SizedBox(height: 8),
              Wrap(
                spacing: 6,
                runSpacing: 6,
                children: [
                  for (final i in kit.pendingItems)
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: kKitRed.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(8),
                        border:
                        Border.all(color: kKitRed.withOpacity(0.25)),
                      ),
                      child: Text(
                        '${i.name} ×${i.pendingQty} pending',
                        style: const TextStyle(
                          color: kKitRed,
                          fontWeight: FontWeight.w700,
                          fontSize: 11,
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}