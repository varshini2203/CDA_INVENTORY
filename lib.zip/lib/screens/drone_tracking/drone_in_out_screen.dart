// lib/screens/drone/drone_in_out_screen.dart
//
// Firestore version — IDs are Strings. Theme matched to Invoice pages.

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'dart:math' as math;
import '../../models/drone.dart';
import '../../services/drone_service.dart';
import '../../services/drone_reminder_service.dart';
import '../../data/seed_drones.dart';
import '../../widgets/common/serial_scan_screen.dart';
import 'add_drone_entry_screen.dart';
import 'edit_drone_screen.dart';
import 'drone_history_screen.dart';
import 'drone_inout_history_screen.dart';

// Drone group filter options — straight from the fleet list (DRONE_LIST.xlsx):
// TC Drones, DJI Drones, FPV Drones, Fixed Wings. Values match Drone.category.
const List<String> kDroneCategoryOptions = kDroneGroups;

class DroneInOutScreen extends StatefulWidget {
  const DroneInOutScreen({super.key});

  @override
  State<DroneInOutScreen> createState() => _DroneInOutScreenState();
}

class _DroneInOutScreenState extends State<DroneInOutScreen>
    with TickerProviderStateMixin {
  final DroneService _service = DroneService();
  List<Drone> _drones = []; // dashboard list: drones with a recorded movement
  List<Drone> _fleet = []; // whole fleet — used for the header Total / IN / OUT
  bool _loading = true;
  bool _seeding = false;
  String? _error;
  String _search = '';
  String _filter = 'ALL';
  // 'ALL' | 'TC Drones' | 'DJI Drones' | ... (see kDroneCategoryOptions)
  String _categoryFilter = 'ALL';
  // 'newest' | 'oldest' | 'date'
  String _sortOption = 'newest';
  DateTime? _sortDate; // used when _sortOption == 'date'
  final TextEditingController _searchCtrl = TextEditingController();
  late AnimationController _headerAnim;
  late AnimationController _droneAnim;
  late AnimationController _radarAnim;

  // ── Design tokens (matches Invoice pages) ──────────────────────────────────
  static const Color kNavy = Color(0xFF0A1628);
  static const Color kNavyLight = Color(0xFF162944);
  static const Color kTeal = Color(0xFF00D4AA);
  static const Color kCoral = Color(0xFFFF6B6B);
  static const Color kAmber = Color(0xFFFFB800);
  static const Color kSurface = Color(0xFFF0F4F8);
  static const Color kGreen = Color(0xFF00B894);
  static const Color kPurple = Color(0xFF6C63FF);

  @override
  void initState() {
    super.initState();
    _headerAnim =
        AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _droneAnim =
    AnimationController(vsync: this, duration: const Duration(seconds: 4))
      ..repeat();
    _radarAnim =
    AnimationController(vsync: this, duration: const Duration(seconds: 3))
      ..repeat();
    _loadDrones();
  }

  @override
  void dispose() {
    _searchCtrl.dispose();
    _headerAnim.dispose();
    _droneAnim.dispose();
    _radarAnim.dispose();
    super.dispose();
  }

  Future<void> _loadDrones() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final result = await _service.getDrones();
    final recs = result.success ? await _service.getMovementRecords() : null;
    if (!mounted) return;
    setState(() {
      _loading = false;
      if (result.success) {
        _drones = recs?.success == true
            ? recs!.data!
            : result.data!.where((d) => d.hasMovement).toList();
        // Dashboard lists only drones that have a recorded IN/OUT movement.
        _fleet = result.data!;
        _headerAnim.forward(from: 0);
      } else {
        _error = result.error;
      }
    });
    // Quietly fill in any missing In/Out timestamps for drones toggled
    // before checked_in_at/checked_out_at existed (see
    // backfillCheckInOutTimestamps() in drone_service.dart). Runs after
    // the list is already on screen so it never blocks the initial load;
    // if it finds anything to fix, silently refreshes the list once more
    // so the corrected dates show up without the person having to do
    // anything.
    if (result.success && result.data!.isNotEmpty) {
      final updated =
      await _service.backfillCheckInOutTimestamps(result.data!);
      if (updated > 0 && mounted) {
        final refreshed = await _service.getDrones(forceRefresh: true);
        final refRecs = refreshed.success
            ? await _service.getMovementRecords()
            : null;
        if (mounted && refreshed.success) {
          setState(() {
            _fleet = refreshed.data!;
            _drones = refRecs?.success == true
                ? refRecs!.data!
                : refreshed.data!.where((d) => d.hasMovement).toList();
          });
        }
      }
    }
  }

  /// Loads the fleet list (DRONE_LIST.xlsx → `lib/data/seed_drones.dart`)
  /// into the `drones` Firestore collection. Safe to run more than once —
  /// existing drones keep their status, history and IN/OUT times.
  Future<void> _seedFleet() async {
    if (_seeding) return;
    setState(() => _seeding = true);
    try {
      await seedDrones(FirebaseFirestore.instance);
      if (!mounted) return;
      _showSnack(
        'Drone list loaded (${kDroneMasterList.length} drones)',
        icon: Icons.cloud_done_rounded,
        color: kTeal,
      );
      // seedDrones() writes directly to Firestore via a WriteBatch, bypassing
      // DroneService entirely, so its static _dronesCache is never
      // invalidated by the write. Without clearing it here, _loadDrones()
      // below would just return the stale (possibly empty) cached list
      // instead of actually re-querying Firestore.
      DroneService.clearCache();
      await _loadDrones();
    } catch (e) {
      if (!mounted) return;
      _showSnack('Seeding failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _seeding = false);
    }
  }

  /// IN / OUT is always recorded through the entry screen: the drone comes
  /// from the fleet dropdown, and the date, time and handler are automatic.
  Future<void> _toggleStatus(Drone drone) async {
    final done = await Navigator.push<bool>(
        context,
        _slide(AddDroneEntryScreen(
            service: _service, initialDroneId: drone.id)));
    if (done == true) _loadDrones();
  }

  /// Deletes ONE IN/OUT record (not the drone itself).
  Future<void> _deleteDrone(Drone drone) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => _ConfirmDialog(
        title: 'Delete this record?',
        body: 'This ${drone.status == 'OUT' ? 'OUT' : 'IN / OUT'} record of '
            '"${drone.name}" will be removed. The drone stays in the fleet.',
        confirmLabel: 'Delete',
        confirmColor: kCoral,
      ),
    );
    if (confirmed != true) return;
    final result = await _service.deleteMovementRecord(drone);
    if (!mounted) return;
    if (result.success) {
      if (!drone.isPastTrip) {
        DroneReminderService.instance.cancelReminder(drone.id);
      }
      await _loadDrones();
      _showSnack('Record deleted', icon: Icons.delete_outline);
    } else {
      _showSnack('Delete failed: ${result.error}', isError: true);
    }
  }

  /// Scans a drone's serial number and drops it straight into the search
  /// box — reuses the existing `_filtered` matching (which already checks
  /// `d.serialNumber`), so the list narrows to that exact drone.
  Future<void> _scanSerial() async {
    final code = await Navigator.push<String>(
      context,
      MaterialPageRoute(
        builder: (_) => const SerialScanScreen(title: 'Scan Drone Serial'),
      ),
    );
    if (code == null || code.trim().isEmpty || !mounted) return;
    final scanned = code.trim();
    _searchCtrl.text = scanned;
    setState(() => _search = scanned);
    final found = _drones.any(
            (d) => d.serialNumber.toLowerCase() == scanned.toLowerCase());
    if (!found) {
      _showSnack('No drone found for serial "$scanned"', isError: true);
    }
  }

  Future<void> _openAdd() async {
    final added = await Navigator.push(
        context, _slide(AddDroneEntryScreen(service: _service)));
    if (added == true) _loadDrones();
  }

  Future<void> _openEdit(Drone drone) async {
    final updated = await Navigator.push(
        context, _slide(EditDroneScreen(service: _service, drone: drone)));
    if (updated == true) _loadDrones();
  }

  void _openHistory(Drone drone) {
    Navigator.push(
        context, _slide(DroneHistoryScreen(service: _service, drone: drone)));
  }

  // Fleet-wide "who used which drone, when" log — combines the history of
  // every drone into one page, reached from the app bar (Icons.history_rounded).
  void _openAllHistory() {
    Navigator.push(
        context, _slide(DroneInOutHistoryScreen(service: _service)));
  }

  PageRouteBuilder<bool> _slide(Widget page) {
    return PageRouteBuilder<bool>(
      pageBuilder: (_, animation, __) => page,
      transitionsBuilder: (_, animation, __, child) => SlideTransition(
        position: Tween<Offset>(begin: const Offset(1, 0), end: Offset.zero)
            .animate(
            CurvedAnimation(parent: animation, curve: Curves.easeOutCubic)),
        child: child,
      ),
      transitionDuration: const Duration(milliseconds: 300),
    );
  }

  void _showSnack(String msg,
      {bool isError = false, IconData? icon, Color? color}) {
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          if (icon != null) ...[
            Icon(icon, color: Colors.white, size: 18),
            const SizedBox(width: 8)
          ],
          Flexible(
              child: Text(msg, style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: isError ? kCoral : (color ?? kTeal),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        margin: const EdgeInsets.all(16),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  List<Drone> get _filtered => _drones.where((d) {
    final matchSearch = _search.isEmpty ||
        d.name.toLowerCase().contains(_search.toLowerCase()) ||
        d.model.toLowerCase().contains(_search.toLowerCase()) ||
        d.serialNumber.toLowerCase().contains(_search.toLowerCase()) ||
        (d.uin ?? '').toLowerCase().contains(_search.toLowerCase()) ||
        (d.gps ?? '').toLowerCase().contains(_search.toLowerCase()) ||
        (d.linkType ?? '').toLowerCase().contains(_search.toLowerCase()) ||
        (d.pilotName ?? '').toLowerCase().contains(_search.toLowerCase());
    final matchFilter = _filter == 'ALL' || d.status == _filter;
    final matchCategory =
        _categoryFilter == 'ALL' || d.category == _categoryFilter;
    final matchDate = _sortOption != 'date' ||
        _sortDate == null ||
        (d.lastUpdated != null && _isSameDate(d.lastUpdated!, _sortDate!));
    return matchSearch &&
        matchFilter &&
        matchCategory &&
        matchDate;
  }).toList()
    ..sort((a, b) {
      final at = a.lastUpdated;
      final bt = b.lastUpdated;
      if (at == null && bt == null) return 0;
      if (at == null) return 1; // undated drones sink to the bottom
      if (bt == null) return -1;
      return _sortOption == 'oldest' ? at.compareTo(bt) : bt.compareTo(at);
    });

  bool _isSameDate(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  int _categoryCount(String category) =>
      _drones.where((d) => d.category == category).length;

  int get _inCount => _drones.where((d) => d.status == 'IN').length;
  int get _outCount => _drones.where((d) => d.status == 'OUT').length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSurface,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverPersistentHeader(
            pinned: true,
            delegate: _DroneHeaderDelegate(
              droneAnim: _droneAnim,
              radarAnim: _radarAnim,
              headerAnim: _headerAnim,
              drones: _fleet,
              inCount: _fleet.where((d) => d.status == 'IN').length,
              outCount: _fleet.where((d) => d.status == 'OUT').length,
              loading: _loading,
              seeding: _seeding,
              onRefresh: _loadDrones,
              onSeed: _seedFleet,
              onBack: () => Navigator.maybePop(context),
              onHistory: _openAllHistory,
            ),
          ),
          if (!_loading && _error == null && _drones.isNotEmpty)
            SliverToBoxAdapter(child: _buildSearchBar()),
          if (!_loading && _error == null && _drones.isNotEmpty)
            SliverToBoxAdapter(child: _buildFilterRow()),
          if (!_loading && _error == null && _drones.isNotEmpty)
            SliverToBoxAdapter(child: _buildCategoryFilterRow()),
          if (!_loading && _error == null && _sortOption == 'date' && _sortDate != null)
            SliverToBoxAdapter(child: _buildDateFilterChip()),
          _buildContent(),
        ],
      ),
      floatingActionButton:
      _loading || _error != null ? null : _buildFAB(),
    );
  }

  Widget _buildFAB() {
    return FloatingActionButton.extended(
      onPressed: _openAdd,
      backgroundColor: kTeal,
      foregroundColor: Colors.white,
      elevation: 2,
      shape:
      RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      icon: const Icon(Icons.swap_vert_rounded, size: 22),
      label: const Text('Drone IN / OUT',
          style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 14,
              letterSpacing: 0.3)),
    );
  }

  Widget _buildSearchBar() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: Colors.grey.shade200, width: 1),
                color: Colors.white,
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.04),
                      blurRadius: 8,
                      offset: const Offset(0, 2)),
                ],
              ),
              child: TextField(
                controller: _searchCtrl,
                onChanged: (v) => setState(() => _search = v),
                style: const TextStyle(color: kNavy, fontSize: 14),
                cursorColor: kTeal,
                decoration: InputDecoration(
                  hintText: 'Search by name, UIN, GPS, Analog / Digital, used by…',
                  hintStyle:
                  TextStyle(color: Colors.grey.shade400, fontSize: 14),
                  prefixIcon:
                  const Icon(Icons.search, color: kTeal, size: 20),
                  suffixIcon: _search.isNotEmpty
                      ? IconButton(
                    icon: Icon(Icons.close,
                        color: Colors.grey.shade500, size: 18),
                    onPressed: () {
                      _searchCtrl.clear();
                      setState(() => _search = '');
                    },
                  )
                      : null,
                  filled: false,
                  contentPadding: const EdgeInsets.symmetric(vertical: 15),
                  border: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  focusedBorder: InputBorder.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Container(
            height: 48,
            width: 48,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.grey.shade200, width: 1),
              color: Colors.white,
              boxShadow: [
                BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 8,
                    offset: const Offset(0, 2)),
              ],
            ),
            child: IconButton(
              icon: const Icon(Icons.qr_code_scanner_rounded, color: kTeal, size: 22),
              tooltip: 'Scan drone serial',
              onPressed: _scanSerial,
            ),
          ),
          const SizedBox(width: 10),
          _SortButton(
            sortOption: _sortOption,
            sortDate: _sortDate,
            onTap: _openSortSheet,
          ),
        ],
      ),
    );
  }

  Future<void> _openSortSheet() async {
    final result = await showModalBottomSheet<_SortSelection>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => _SortSheet(
        current: _sortOption,
        currentDate: _sortDate,
      ),
    );
    if (result == null) return;

    if (result.option == 'date') {
      final picked = await showDatePicker(
        context: context,
        initialDate: result.date ?? DateTime.now(),
        firstDate: DateTime.now().subtract(const Duration(days: 365)),
        lastDate: DateTime.now().add(const Duration(days: 1)),
      );
      if (picked == null) return; // cancelled date pick, keep old sort
      setState(() {
        _sortOption = 'date';
        _sortDate = picked;
      });
    } else {
      setState(() {
        _sortOption = result.option;
        _sortDate = null;
      });
    }
  }

  Widget _buildFilterRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      child: Row(
        children: [
          _FilterChip(
              label: 'All',
              count: _drones.length,
              selected: _filter == 'ALL',
              color: kNavy,
              onTap: () => setState(() => _filter = 'ALL')),
          const SizedBox(width: 8),
          _FilterChip(
              label: 'IN',
              count: _inCount,
              selected: _filter == 'IN',
              color: kTeal,
              onTap: () => setState(() => _filter = 'IN')),
          const SizedBox(width: 8),
          _FilterChip(
              label: 'OUT',
              count: _outCount,
              selected: _filter == 'OUT',
              color: kAmber,
              onTap: () => setState(() => _filter = 'OUT')),
        ],
      ),
    );
  }

  /// Drone-type filter row — "All Types", "RPTO Aerial", "FPV", etc.
  /// Same chip pattern as the branch filter row above; filters on
  /// Drone.category (see kDroneCategoryOptions at the top of this file).
  Widget _buildCategoryFilterRow() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          children: [
            _FilterChip(
                label: 'All Drones',
                count: _drones.length,
                selected: _categoryFilter == 'ALL',
                color: kGreen,
                onTap: () => setState(() => _categoryFilter = 'ALL')),
            for (final type in kDroneCategoryOptions) ...[
              const SizedBox(width: 8),
              _FilterChip(
                  label: type,
                  count: _categoryCount(type),
                  selected: _categoryFilter == type,
                  color: kGreen,
                  onTap: () => setState(() => _categoryFilter = type)),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildDateFilterChip() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: GestureDetector(
        onTap: () => setState(() {
          _sortOption = 'newest';
          _sortDate = null;
        }),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          decoration: BoxDecoration(
            color: kTeal.withOpacity(0.1),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: kTeal.withOpacity(0.4)),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.calendar_today_outlined, size: 13, color: kTeal),
              const SizedBox(width: 6),
              Text('Showing ${DateFormat('dd MMM yyyy').format(_sortDate!)}',
                  style: const TextStyle(
                      color: kTeal, fontSize: 12, fontWeight: FontWeight.w700)),
              const SizedBox(width: 6),
              const Icon(Icons.close_rounded, size: 14, color: kTeal),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildContent() {
    if (_loading) {
      return SliverFillRemaining(
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _PulsingDroneIcon(droneAnim: _droneAnim),
              const SizedBox(height: 20),
              const Text('Scanning fleet…',
                  style: TextStyle(
                      color: kTeal,
                      fontSize: 14,
                      letterSpacing: 1)),
            ],
          ),
        ),
      );
    }
    if (_error != null) {
      return SliverFillRemaining(
          child: _ErrorView(message: _error!, onRetry: _loadDrones));
    }
    final items = _filtered;
    if (_drones.isEmpty) {
      return SliverFillRemaining(
          child: _EmptyView(
              onAdd: _openAdd));
    }
    if (items.isEmpty) {
      return SliverFillRemaining(
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(Icons.search_off, size: 52, color: Colors.grey.shade300),
            const SizedBox(height: 12),
            Text('No matches',
                style:
                TextStyle(color: Colors.grey.shade500, fontSize: 16)),
          ]),
        ),
      );
    }
    return SliverPadding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 100),
      sliver: SliverList(
        delegate: SliverChildBuilderDelegate(
              (_, i) => _DroneCard(
            drone: items[i],
            onToggle: () => _toggleStatus(items[i]),
            onEdit: () => _openEdit(items[i]),
            onDelete: () => _deleteDrone(items[i]),
            onHistory: () => _openHistory(items[i]),
          ),
          childCount: items.length,
        ),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════════════════════
// HEADER DELEGATE
// ══════════════════════════════════════════════════════════════════════════════

class _DroneHeaderDelegate extends SliverPersistentHeaderDelegate {
  final AnimationController droneAnim;
  final AnimationController radarAnim;
  final AnimationController headerAnim;
  final List<Drone> drones;
  final int inCount, outCount;
  final bool loading;
  final bool seeding;
  final VoidCallback onRefresh;
  final VoidCallback onSeed;
  final VoidCallback onBack;
  final VoidCallback onHistory;

  static const Color kNavy = Color(0xFF0A1628);
  static const Color kNavyLight = Color(0xFF162944);
  static const Color kTeal = Color(0xFF00D4AA);
  static const Color kAmber = Color(0xFFFFB800);

  const _DroneHeaderDelegate({
    required this.droneAnim,
    required this.radarAnim,
    required this.headerAnim,
    required this.drones,
    required this.inCount,
    required this.outCount,
    required this.loading,
    required this.seeding,
    required this.onRefresh,
    required this.onSeed,
    required this.onBack,
    required this.onHistory,
  });

  static const double _pinnedHeight = 56.0;
  static const double _expandedHeight = 220.0;

  @override
  double get minExtent => _pinnedHeight;

  @override
  double get maxExtent => _expandedHeight;

  @override
  bool shouldRebuild(_DroneHeaderDelegate old) => true;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    final statusBarHeight = MediaQuery.of(context).padding.top;
    final expandRatio =
    (1 - shrinkOffset / (_expandedHeight - _pinnedHeight))
        .clamp(0.0, 1.0);
    final isCollapsed = expandRatio < 0.1;

    return SizedBox.expand(
      child: Stack(
        fit: StackFit.expand,
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [kNavy, kNavyLight],
              ),
            ),
          ),
          Positioned.fill(child: CustomPaint(painter: _GridPainter())),
          Positioned(
            right: -20,
            top: -20,
            child: AnimatedBuilder(
              animation: radarAnim,
              builder: (_, __) => CustomPaint(
                size: const Size(200, 200),
                painter: _RadarPainter(radarAnim.value),
              ),
            ),
          ),
          if (expandRatio > 0.2)
            AnimatedBuilder(
              animation: droneAnim,
              builder: (_, __) => Opacity(
                opacity: expandRatio,
                child: Stack(children: [
                  _FloatingDrone(
                      progress: droneAnim.value,
                      startX: 0.15,
                      startY: 0.25,
                      maxHeight: _expandedHeight,
                      size: 18,
                      speed: 1.0),
                  _FloatingDrone(
                      progress: droneAnim.value,
                      startX: 0.65,
                      startY: 0.45,
                      maxHeight: _expandedHeight,
                      size: 14,
                      speed: 1.4),
                  _FloatingDrone(
                      progress: droneAnim.value,
                      startX: 0.40,
                      startY: 0.60,
                      maxHeight: _expandedHeight,
                      size: 10,
                      speed: 0.7),
                ]),
              ),
            ),
          Positioned(
            left: 20,
            right: 20,
            bottom: 16,
            child: Opacity(
              opacity: expandRatio.clamp(0.0, 1.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: kTeal.withOpacity(0.16),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                          color: kTeal.withOpacity(0.4)),
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(Icons.radar,
                            color: kTeal.withOpacity(0.95),
                            size: 14),
                        const SizedBox(width: 6),
                        const Text('CHENNAI DRONE ACADEMY FLEET',
                            style: TextStyle(
                                color: kTeal,
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                letterSpacing: 2.5)),
                      ],
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (!loading)
                    FadeTransition(
                      opacity: headerAnim,
                      child: Row(
                        children: [
                          _StatPill(
                              label: 'Total',
                              value: '${drones.length}',
                              color: Colors.white),
                          const SizedBox(width: 10),
                          _StatPill(
                              label: 'IN',
                              value: '$inCount',
                              color: kTeal),
                          const SizedBox(width: 10),
                          _StatPill(
                              label: 'OUT',
                              value: '$outCount',
                              color: kAmber),
                        ],
                      ),
                    ),
                ],
              ),
            ),
          ),
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: _pinnedHeight + statusBarHeight,
            child: Container(
              decoration: BoxDecoration(
                color: isCollapsed ? kNavy : Colors.transparent,
                border: isCollapsed
                    ? Border(
                    bottom:
                    BorderSide(color: Colors.white.withOpacity(0.08), width: 1))
                    : null,
              ),
              padding: EdgeInsets.only(top: statusBarHeight),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back_ios_new_rounded,
                        color: Colors.white, size: 20),
                    onPressed: onBack,
                  ),
                  if (isCollapsed) ...[
                    Container(
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: kTeal,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                              color: kTeal.withOpacity(0.8),
                              blurRadius: 6)
                        ],
                      ),
                    ),
                    const SizedBox(width: 10),
                    const Text(
                      'Drone Control',
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 17,
                          letterSpacing: 0.3),
                    ),
                  ],
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.history_rounded,
                        color: Colors.white),
                    onPressed: onHistory,
                    tooltip: 'Drone In/Out history',
                  ),
                  IconButton(
                    icon: seeding
                        ? const SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            color: Colors.white, strokeWidth: 2))
                        : const Icon(Icons.cloud_upload_rounded,
                        color: Colors.white),
                    onPressed: seeding ? null : onSeed,
                    tooltip: 'Load drone list',
                  ),
                  IconButton(
                    icon: const Icon(Icons.refresh_rounded,
                        color: Colors.white),
                    onPressed: onRefresh,
                    tooltip: 'Refresh',
                  ),
                  const SizedBox(width: 4),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ── Floating drone ────────────────────────────────────────────────────────────

class _FloatingDrone extends StatelessWidget {
  final double progress, startX, startY, maxHeight, size, speed;
  const _FloatingDrone(
      {required this.progress,
        required this.startX,
        required this.startY,
        required this.maxHeight,
        required this.size,
        required this.speed});

  @override
  Widget build(BuildContext context) {
    final t = (progress * speed) % 1.0;
    final xWave = math.sin(t * 2 * math.pi) * 0.08;
    final yWave = math.cos(t * 2 * math.pi * 0.7) * 0.06;
    final top = (maxHeight * (startY + yWave)).clamp(60.0, maxHeight - 40);
    return Positioned(
      left: MediaQuery.of(context).size.width * (startX + xWave),
      top: top,
      child: Opacity(
        opacity: 0.22,
        child: Icon(Icons.flight_rounded,
            color: const Color(0xFF00D4AA), size: size),
      ),
    );
  }
}

// ── Stat Pill ─────────────────────────────────────────────────────────────────

class _StatPill extends StatelessWidget {
  final String label, value;
  final Color color;
  const _StatPill(
      {required this.label, required this.value, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(value,
              style: TextStyle(
                  color: color,
                  fontSize: 17,
                  fontWeight: FontWeight.w800)),
          const SizedBox(width: 6),
          Text(label,
              style: TextStyle(
                  color: color.withOpacity(0.75),
                  fontSize: 12,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

// ── Filter Chip ───────────────────────────────────────────────────────────────

class _FilterChip extends StatelessWidget {
  final String label;
  final int count;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  const _FilterChip(
      {required this.label,
        required this.count,
        required this.selected,
        required this.color,
        required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding:
        const EdgeInsets.symmetric(horizontal: 16, vertical: 9),
        decoration: BoxDecoration(
          color: selected ? color.withOpacity(0.12) : Colors.white,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(
            color: selected
                ? color.withOpacity(0.6)
                : Colors.grey.shade200,
            width: selected ? 1.5 : 1,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(label,
                style: TextStyle(
                  color: selected ? color : Colors.grey.shade500,
                  fontWeight: selected
                      ? FontWeight.w700
                      : FontWeight.w500,
                  fontSize: 13,
                )),
            const SizedBox(width: 7),
            Container(
              padding: const EdgeInsets.symmetric(
                  horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                color: selected
                    ? color.withOpacity(0.18)
                    : Colors.grey.shade100,
                borderRadius: BorderRadius.circular(10),
              ),
              child: Text('$count',
                  style: TextStyle(
                    color: selected ? color : Colors.grey.shade500,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                  )),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Sort Button + Sheet ────────────────────────────────────────────────────────

class _SortSelection {
  final String option; // 'newest' | 'oldest' | 'date'
  final DateTime? date;
  const _SortSelection(this.option, [this.date]);
}

class _SortButton extends StatelessWidget {
  final String sortOption;
  final DateTime? sortDate;
  final VoidCallback onTap;
  const _SortButton(
      {required this.sortOption, required this.sortDate, required this.onTap});

  static const Color kNavy = Color(0xFF0A1628);
  static const Color kTeal = Color(0xFF00D4AA);

  bool get _isActive => sortOption != 'newest';

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52,
        width: 52,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
              color: _isActive ? kTeal.withOpacity(0.5) : Colors.grey.shade200),
          color: _isActive ? kTeal.withOpacity(0.08) : Colors.white,
          boxShadow: [
            BoxShadow(
                color: Colors.black.withOpacity(0.04),
                blurRadius: 8,
                offset: const Offset(0, 2)),
          ],
        ),
        child: Icon(Icons.sort_rounded,
            color: _isActive ? kTeal : kNavy.withOpacity(0.6), size: 22),
      ),
    );
  }
}

class _SortSheet extends StatelessWidget {
  final String current;
  final DateTime? currentDate;
  const _SortSheet({required this.current, required this.currentDate});

  static const Color kNavy = Color(0xFF0A1628);
  static const Color kTeal = Color(0xFF00D4AA);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Container(
        margin: const EdgeInsets.all(12),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(22),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
              child: Text('Sort by',
                  style: TextStyle(
                      color: kNavy, fontSize: 16, fontWeight: FontWeight.w800)),
            ),
            _SortOptionTile(
              icon: Icons.arrow_downward_rounded,
              label: 'Newest to oldest',
              selected: current == 'newest',
              onTap: () => Navigator.pop(context, const _SortSelection('newest')),
            ),
            _SortOptionTile(
              icon: Icons.arrow_upward_rounded,
              label: 'Oldest to newest',
              selected: current == 'oldest',
              onTap: () => Navigator.pop(context, const _SortSelection('oldest')),
            ),
            _SortOptionTile(
              icon: Icons.calendar_today_outlined,
              label: current == 'date' && currentDate != null
                  ? 'Date · ${DateFormat('dd MMM yyyy').format(currentDate!)}'
                  : 'Pick a date',
              selected: current == 'date',
              onTap: () =>
                  Navigator.pop(context, _SortSelection('date', currentDate)),
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }
}

class _SortOptionTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const _SortOptionTile(
      {required this.icon,
        required this.label,
        required this.selected,
        required this.onTap});

  static const Color kNavy = Color(0xFF0A1628);
  static const Color kTeal = Color(0xFF00D4AA);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 13),
        child: Row(
          children: [
            Icon(icon, size: 19, color: selected ? kTeal : Colors.grey.shade500),
            const SizedBox(width: 14),
            Expanded(
              child: Text(label,
                  style: TextStyle(
                      color: selected ? kTeal : kNavy,
                      fontSize: 14,
                      fontWeight: selected ? FontWeight.w700 : FontWeight.w500)),
            ),
            if (selected) const Icon(Icons.check_rounded, color: kTeal, size: 18),
          ],
        ),
      ),
    );
  }
}

// ── Drone Card ────────────────────────────────────────────────────────────────

class _DroneCard extends StatefulWidget {
  final Drone drone;
  final VoidCallback onToggle, onEdit, onDelete, onHistory;
  const _DroneCard(
      {required this.drone,
        required this.onToggle,
        required this.onEdit,
        required this.onDelete,
        required this.onHistory});

  @override
  State<_DroneCard> createState() => _DroneCardState();
}

class _DroneCardState extends State<_DroneCard>
    with SingleTickerProviderStateMixin {
  late AnimationController _hoverAnim;

  static const Color kNavy = Color(0xFF0A1628);
  static const Color kTeal = Color(0xFF00D4AA);
  static const Color kCoral = Color(0xFFFF6B6B);
  static const Color kAmber = Color(0xFFFFB800);
  static const Color kPurple = Color(0xFF6C63FF);

  @override
  void initState() {
    super.initState();
    _hoverAnim = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 150));
  }

  @override
  void dispose() {
    _hoverAnim.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isIn = widget.drone.status == 'IN';
    final statusColor = isIn ? kTeal : kAmber;

    return GestureDetector(
      onTapDown: (_) => _hoverAnim.forward(),
      onTapUp: (_) => _hoverAnim.reverse(),
      onTapCancel: () => _hoverAnim.reverse(),
      child: AnimatedBuilder(
        animation: _hoverAnim,
        builder: (_, child) => Transform.scale(
          scale: 1.0 - (_hoverAnim.value * 0.01),
          child: child,
        ),
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 16,
                spreadRadius: 0,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: Column(
            children: [
              Container(
                height: 2,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    statusColor.withOpacity(0.9),
                    statusColor.withOpacity(0.15)
                  ]),
                  borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(20)),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ── Row 1: status · name · small actions ──────────────
                    Row(
                      children: [
                        _StatusBadge(
                            status: widget.drone.status, color: statusColor),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Text(widget.drone.name,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: kNavy,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w800)),
                        ),
                        if (widget.drone.isLockedRecord)
                          Padding(
                            padding: const EdgeInsets.only(right: 8),
                            child: Row(children: [
                              Icon(Icons.lock_outline_rounded,
                                  size: 14, color: Colors.grey.shade500),
                              const SizedBox(width: 4),
                              Text('Completed',
                                  style: TextStyle(
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.grey.shade500)),
                            ]),
                          ),
                        _MiniBtn(
                            icon: Icons.history_rounded,
                            color: kPurple,
                            tooltip: 'History',
                            onTap: widget.onHistory),
                        // A finished OUT→IN record is frozen — no edit, no delete.
                        if (!widget.drone.isLockedRecord) ...[
                          const SizedBox(width: 6),
                          _MiniBtn(
                              icon: Icons.edit_outlined,
                              color: kAmber,
                              tooltip: 'Edit',
                              onTap: widget.onEdit),
                        ],
                      ],
                    ),
                    const SizedBox(height: 6),
                    // ── Row 2: compact info chips ─────────────────────────
                    Wrap(
                      spacing: 6,
                      runSpacing: 4,
                      crossAxisAlignment: WrapCrossAlignment.center,
                      children: [
                        if (widget.drone.category != null)
                          _DetailChip(
                              icon: Icons.category_outlined,
                              text: widget.drone.category!,
                              color: kNavy),
                        if (widget.drone.uin != null)
                          _DetailChip(
                              icon: Icons.fingerprint,
                              text: 'UIN ${widget.drone.uin!}',
                              color: kPurple),
                        if (widget.drone.gps != null)
                          _DetailChip(
                              icon: Icons.gps_fixed_rounded,
                              text: 'GPS ${widget.drone.gps!}',
                              color: const Color(0xFF00B894)),
                        if (widget.drone.linkType != null)
                          _DetailChip(
                              icon: widget.drone.linkType == 'Digital'
                                  ? Icons.settings_input_antenna_rounded
                                  : Icons.podcasts_rounded,
                              text: widget.drone.linkType!,
                              color: widget.drone.linkType == 'Digital'
                                  ? kTeal
                                  : kAmber),
                        if (widget.drone.pilotName != null &&
                            widget.drone.pilotName!.isNotEmpty)
                          _DetailChip(
                              icon: Icons.person_outline,
                              text: widget.drone.pilotName!,
                              color: kPurple),
                      ],
                    ),
                    if (widget.drone.status == 'OUT' &&
                        widget.drone.additionalProducts.isNotEmpty) ...[
                      const SizedBox(height: 4),
                      Text(
                          'With: ${widget.drone.additionalProducts.join(', ')}',
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                              color: Colors.grey.shade600, fontSize: 11)),
                    ],
                    if (widget.drone.maintenanceDue != null) ...[
                      const SizedBox(height: 6),
                      _MaintenanceBadge(
                          dueDate: widget.drone.maintenanceDue!),
                    ],
                    if (widget.drone.checkedInAt != null ||
                        widget.drone.checkedOutAt != null) ...[
                      const SizedBox(height: 6),
                      _InOutDateStrip(
                        checkedInAt: widget.drone.checkedInAt,
                        checkedOutAt: widget.drone.checkedOutAt,
                      ),
                    ],
                    // ── Action: only on the latest record of a drone ──────
                    // Like Inventory Movement: only an OPEN (OUT) record has an
                    // action — Bring IN. A completed record has none, and a new
                    // OUT is only started from the Drone IN / OUT button.
                    if (!widget.drone.isPastTrip &&
                        widget.drone.status == 'OUT') ...[
                      const SizedBox(height: 8),
                      GestureDetector(
                        onTap: widget.onToggle,
                        child: Container(
                          width: double.infinity,
                          padding: const EdgeInsets.symmetric(vertical: 7),
                          decoration: BoxDecoration(
                            color: statusColor.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                                color: statusColor.withOpacity(0.4)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(
                                  isIn
                                      ? Icons.flight_takeoff_rounded
                                      : Icons.flight_land_rounded,
                                  color: statusColor,
                                  size: 14),
                              const SizedBox(width: 6),
                              Text(isIn ? 'Send OUT' : 'Bring IN',
                                  style: TextStyle(
                                      color: statusColor,
                                      fontWeight: FontWeight.w700,
                                      fontSize: 12)),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── In/Out Date Strip ─────────────────────────────────────────────────────
// Split two-tone bar showing the last OUT time (left, coral/pink) and last
// IN time (right, green) side by side — same visual language as the
// check-in/check-out strip used elsewhere in the app (Inventory Movement
// history). Whichever side is missing (e.g. a drone that's never been OUT
// yet) is skipped and the other side takes the full width.

class _InOutDateStrip extends StatelessWidget {
  final DateTime? checkedInAt;
  final DateTime? checkedOutAt;
  const _InOutDateStrip({this.checkedInAt, this.checkedOutAt});

  static const Color _kCoral = Color(0xFFFF6B6B);
  static const Color _kGreen = Color(0xFF00B894);

  @override
  Widget build(BuildContext context) {
    final fmt = DateFormat('d MMM, h:mm a');
    final segments = <Widget>[];

    if (checkedOutAt != null) {
      segments.add(Expanded(
        child: _segment(
          color: _kCoral,
          icon: Icons.flight_takeoff_rounded,
          label: 'Out',
          value: fmt.format(checkedOutAt!),
          alignEnd: false,
        ),
      ));
    }
    if (checkedInAt != null) {
      segments.add(Expanded(
        child: _segment(
          color: _kGreen,
          icon: Icons.flight_land_rounded,
          label: 'In',
          value: fmt.format(checkedInAt!),
          alignEnd: true,
        ),
      ));
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(10),
      child: Row(
        children: [
          for (var i = 0; i < segments.length; i++) ...[
            if (i > 0) Container(width: 1, height: 26, color: Colors.white),
            segments[i],
          ],
        ],
      ),
    );
  }

  Widget _segment({
    required Color color,
    required IconData icon,
    required String label,
    required String value,
    required bool alignEnd,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 5),
      color: color.withOpacity(0.1),
      child: Row(
        mainAxisAlignment:
        alignEnd ? MainAxisAlignment.end : MainAxisAlignment.start,
        children: [
          if (!alignEnd) ...[
            Icon(icon, size: 12, color: color),
            const SizedBox(width: 5),
          ],
          Flexible(
            child: Text('$label: $value',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: color,
                    fontSize: 11,
                    fontWeight: FontWeight.w700)),
          ),
          if (alignEnd) ...[
            const SizedBox(width: 5),
            Icon(icon, size: 12, color: color),
          ],
        ],
      ),
    );
  }
}

// ── Detail chip (UIN / GPS / Analog-Digital / group) ─────────────────────────

class _DetailChip extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;
  const _DetailChip(
      {required this.icon, required this.text, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 11, color: color),
          const SizedBox(width: 4),
          Flexible(
            child: Text(text,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(
                    color: color,
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }
}

// ── Status Badge ──────────────────────────────────────────────────────────────

class _StatusBadge extends StatelessWidget {
  final String status;
  final Color color;
  const _StatusBadge({required this.status, required this.color});

  @override
  Widget build(BuildContext context) {
    final isIn = status == 'IN';
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
              isIn
                  ? Icons.flight_land_rounded
                  : Icons.flight_takeoff_rounded,
              color: color,
              size: 13),
          const SizedBox(width: 5),
          Text(status,
              style: TextStyle(
                  color: color,
                  fontWeight: FontWeight.w800,
                  fontSize: 12,
                  letterSpacing: 1.2)),
        ],
      ),
    );
  }
}

// ── Action Button ─────────────────────────────────────────────────────────────

class _MiniBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String tooltip;
  final VoidCallback onTap;
  const _MiniBtn(
      {required this.icon,
        required this.color,
        required this.tooltip,
        required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(6),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Icon(icon, color: color, size: 15),
        ),
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String tooltip;
  final VoidCallback onTap;
  const _ActionBtn(
      {required this.icon,
        required this.color,
        required this.tooltip,
        required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: tooltip,
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: color.withOpacity(0.08),
            borderRadius: BorderRadius.circular(11),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Icon(icon, color: color, size: 18),
        ),
      ),
    );
  }
}

// ── Maintenance Badge ─────────────────────────────────────────────────────────

class _MaintenanceBadge extends StatelessWidget {
  final DateTime dueDate;
  const _MaintenanceBadge({required this.dueDate});

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final daysLeft =
        dueDate.difference(DateTime(now.year, now.month, now.day)).inDays;
    final overdue = daysLeft < 0;
    final dueSoon = daysLeft >= 0 && daysLeft <= 7;
    final color = overdue
        ? const Color(0xFFFF6B6B)
        : dueSoon
        ? const Color(0xFFFFB800)
        : Colors.grey.shade500;
    final label = overdue
        ? 'Overdue by ${-daysLeft}d'
        : daysLeft == 0
        ? 'Due today'
        : 'Due in ${daysLeft}d';

    return Container(
      padding:
      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: color.withOpacity(0.35)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.build_outlined, color: color, size: 13),
          const SizedBox(width: 5),
          Text('Maintenance · $label',
              style: TextStyle(
                  color: color,
                  fontSize: 12,
                  fontWeight: FontWeight.w500)),
        ],
      ),
    );
  }
}

// ── Confirm Dialog ────────────────────────────────────────────────────────────

class _ConfirmDialog extends StatelessWidget {
  final String title, body, confirmLabel;
  final Color confirmColor;
  const _ConfirmDialog(
      {required this.title,
        required this.body,
        required this.confirmLabel,
        required this.confirmColor});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
      ),
      title: Row(children: [
        Icon(Icons.delete_outline_rounded, color: confirmColor),
        const SizedBox(width: 8),
        Text(title,
            style: const TextStyle(
                color: Color(0xFF0A1628), fontWeight: FontWeight.bold)),
      ]),
      content: Text(body,
          style:
          TextStyle(color: Colors.grey.shade600, height: 1.5)),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: Text('Cancel',
              style: TextStyle(color: Colors.grey.shade600)),
        ),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, true),
          style: ElevatedButton.styleFrom(
            backgroundColor: confirmColor,
            foregroundColor: Colors.white,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(11)),
          ),
          child: Text(confirmLabel),
        ),
      ],
    );
  }
}

// ── Loading / Empty / Error ───────────────────────────────────────────────────

class _PulsingDroneIcon extends StatelessWidget {
  final AnimationController droneAnim;
  const _PulsingDroneIcon({required this.droneAnim});

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: droneAnim,
      builder: (_, __) {
        final pulse = (math.sin(droneAnim.value * 2 * math.pi) + 1) / 2;
        return Container(
          width: 80,
          height: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(
                color: const Color(0xFF00D4AA)
                    .withOpacity(0.2 + pulse * 0.3),
                width: 1.5),
            color: const Color(0xFF00D4AA)
                .withOpacity(0.05 + pulse * 0.05),
          ),
          child: Icon(Icons.flight_rounded,
              color: const Color(0xFF00D4AA)
                  .withOpacity(0.7 + pulse * 0.3),
              size: 36),
        );
      },
    );
  }
}

class _EmptyView extends StatelessWidget {
  final VoidCallback onAdd;
  const _EmptyView({required this.onAdd});

  static const Color kTeal = Color(0xFF00D4AA);
  static const Color kPurple = Color(0xFF6C63FF);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            padding: const EdgeInsets.all(28),
            decoration: BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
              border:
              Border.all(color: Colors.grey.shade200, width: 2),
            ),
            child: Icon(Icons.flight_rounded,
                size: 52, color: Colors.grey.shade300),
          ),
          const SizedBox(height: 22),
          const Text('No IN / OUT movements yet',
              style: TextStyle(
                  color: Color(0xFF0A1628),
                  fontSize: 20,
                  fontWeight: FontWeight.w700)),
          const SizedBox(height: 8),
          Text('Drones appear here once an IN / OUT movement is recorded.',
              style:
              TextStyle(color: Colors.grey.shade500, fontSize: 14)),
          const SizedBox(height: 30),
          ElevatedButton.icon(
            onPressed: onAdd,
            icon: const Icon(Icons.swap_vert_rounded),
            label: const Text('Drone IN / OUT',
                style: TextStyle(fontWeight: FontWeight.w700)),
            style: ElevatedButton.styleFrom(
              backgroundColor: kTeal,
              foregroundColor: Colors.white,
              padding:
              const EdgeInsets.symmetric(horizontal: 28, vertical: 15),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
            ),
          ),
        ],
      ),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorView({required this.message, required this.onRetry});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: const Color(0xFFFF6B6B).withOpacity(0.08),
                shape: BoxShape.circle,
                border: Border.all(
                    color: const Color(0xFFFF6B6B).withOpacity(0.3)),
              ),
              child: const Icon(Icons.cloud_off_rounded,
                  size: 48, color: Color(0xFFFF6B6B)),
            ),
            const SizedBox(height: 20),
            const Text("Can't reach Firestore",
                style: TextStyle(
                    color: Color(0xFF0A1628),
                    fontSize: 18,
                    fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(message,
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.grey.shade600, fontSize: 13)),
            const SizedBox(height: 6),
            Text(
                'Check your Firebase project config and Firestore security rules.',
                textAlign: TextAlign.center,
                style: TextStyle(
                    color: Colors.grey.shade400, fontSize: 12)),
            const SizedBox(height: 26),
            ElevatedButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('Retry'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF6C63FF),
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Painters ──────────────────────────────────────────────────────────────────

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.05)
      ..strokeWidth = 0.5;
    const spacing = 28.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_) => false;
}

class _RadarPainter extends CustomPainter {
  final double progress;
  _RadarPainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width, 0);
    for (int i = 1; i <= 4; i++) {
      canvas.drawCircle(
          center,
          i * 35.0,
          Paint()
            ..color = const Color(0xFF00D4AA).withOpacity(0.08)
            ..style = PaintingStyle.stroke
            ..strokeWidth = 0.5);
    }
    final angle = progress * 2 * math.pi;
    canvas.drawLine(
        center,
        Offset(center.dx + 140 * math.cos(angle),
            center.dy + 140 * math.sin(angle)),
        Paint()
          ..color = const Color(0xFF00D4AA).withOpacity(0.25)
          ..strokeWidth = 1
          ..style = PaintingStyle.stroke);
  }

  @override
  bool shouldRepaint(_RadarPainter old) => old.progress != progress;
}