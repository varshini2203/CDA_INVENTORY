// lib/screens/reports/stock_history_report_screen.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:cda_inventory/models/stock.dart';
import 'package:cda_inventory/services/report_service.dart';
import 'package:cda_inventory/services/excel_export_service.dart'
    hide MonthlySummary, DroneReportRow, ReportService;
import 'package:cda_inventory/services/pdf_export_service.dart';
class StockHistoryReportScreen extends StatefulWidget {
  final DateTime initialMonth;
  const StockHistoryReportScreen({super.key, required this.initialMonth});

  @override
  State<StockHistoryReportScreen> createState() => _StockHistoryReportScreenState();
}

class _StockHistoryReportScreenState extends State<StockHistoryReportScreen> {
  late DateTime _month;
  List<StockTransaction> _rows = [];
  bool _loading = true;
  bool _busy = false;
  String? _error;

  // ── Design tokens (matches Invoice List screen theme) ──────────────────────
  static const Color kNavy = Color(0xFF0A1628);
  static const Color kTeal = Color(0xFF00D4AA);
  static const Color kCoral = Color(0xFFFF6B6B);
  static const Color kSurface = Color(0xFFF0F4F8);
  static const Color kGreen = Color(0xFF00B894);

  @override
  void initState() {
    super.initState();
    _month = widget.initialMonth;
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final rows =
      await ReportService.fetchStockHistoryReport(_month.year, _month.month);
      setState(() {
        _rows = rows;
        _loading = false;
      });
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _pickMonth() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _month,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 1),
      initialDatePickerMode: DatePickerMode.year,
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(
            primary: kTeal,
            onPrimary: Colors.white,
            surface: Colors.white,
            onSurface: kNavy,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _month = DateTime(picked.year, picked.month));
      _load();
    }
  }

  Future<void> _export({required bool pdf}) async {
    setState(() => _busy = true);
    try {
      final label = DateFormat('MMM_yyyy').format(_month);
      if (pdf) {
        final bytes = await PdfExportService.buildStockReport(_rows, _month);
        await PdfExportService.download(bytes, 'Stock_History_Report_$label.pdf');
      } else {
        final bytes = ExcelExportService.buildStockReport(_rows, _month);
        ExcelExportService.download(bytes, 'Stock_History_Report_$label.xlsx');
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Export failed: $e'), backgroundColor: kCoral));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _previewPdf() async {
    setState(() => _busy = true);
    try {
      final bytes = await PdfExportService.buildStockReport(_rows, _month);
      await PdfExportService.preview(bytes, 'Stock_History_Report');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSurface,
      appBar: AppBar(
        backgroundColor: kNavy,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('Stock History Report',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        actions: [IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _load)],
      ),
      body: Column(children: [
        _monthBar(),
        if (!_loading && _error == null) _statsBar(),
        Expanded(
          child: _loading
              ? const Center(child: CircularProgressIndicator(color: kTeal))
              : _error != null
              ? _errorState()
              : _rows.isEmpty
              ? _emptyState()
              : ListView.builder(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 90),
            itemCount: _rows.length,
            itemBuilder: (_, i) => _card(_rows[i]),
          ),
        ),
      ]),
      bottomNavigationBar: _rows.isEmpty ? null : _exportBar(),
    );
  }

  Widget _monthBar() => Container(
    decoration: const BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: [Color(0xFF0A1628), Color(0xFF162944)],
      ),
    ),
    padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
    child: GestureDetector(
      onTap: _pickMonth,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
        child: Row(children: [
          const Icon(Icons.calendar_month_rounded, color: kTeal, size: 16),
          const SizedBox(width: 8),
          Text(DateFormat('MMMM yyyy').format(_month),
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          const Spacer(),
          Icon(Icons.expand_more_rounded, color: Colors.white.withOpacity(0.6), size: 18),
        ]),
      ),
    ),
  );

  Widget _statsBar() {
    final inQty = _rows.where((r) => r.type == 'IN').fold<int>(0, (s, t) => s + t.quantity);
    final outQty = _rows.where((r) => r.type == 'OUT').fold<int>(0, (s, t) => s + t.quantity);
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Wrap(spacing: 8, runSpacing: 6, children: [
        _pill('${_rows.length} Records', Colors.grey.shade600, kSurface),
        _pill('IN qty $inQty', kGreen, kGreen.withOpacity(0.12)),
        _pill('OUT qty $outQty', kCoral, kCoral.withOpacity(0.12)),
      ]),
    );
  }

  Widget _pill(String label, Color fg, Color bg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(20)),
    child: Text(label, style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w700)),
  );

  Widget _card(StockTransaction t) {
    final isIn = t.type == 'IN';
    final color = isIn ? kGreen : kCoral;
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
        ],
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 40,
            height: 40,
            decoration:
            BoxDecoration(color: color.withOpacity(0.14), borderRadius: BorderRadius.circular(10)),
            child: Icon(isIn ? Icons.arrow_downward_rounded : Icons.arrow_upward_rounded,
                color: color, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t.productName,
                  style: const TextStyle(color: kNavy, fontWeight: FontWeight.w700, fontSize: 14),
                  overflow: TextOverflow.ellipsis),
              Text('${t.date}  •  ${t.time}',
                  style: TextStyle(color: Colors.grey.shade400, fontSize: 11)),
            ]),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
            child: Text(t.type,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 11)),
          ),
        ]),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: kSurface, borderRadius: BorderRadius.circular(10)),
          child: Row(children: [
            Expanded(child: _detail('QTY', '${t.quantity}', color)),
            _divider(),
            Expanded(child: _detail('BRANCH', t.branch, Colors.grey.shade600)),
            _divider(),
            Expanded(child: _detail('PERSON', t.person, Colors.grey.shade600)),
          ]),
        ),
        if (t.departmentOrPurpose.isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(t.departmentOrPurpose,
              style: TextStyle(color: Colors.grey.shade400, fontSize: 11.5),
              overflow: TextOverflow.ellipsis),
        ],
      ]),
    );
  }

  Widget _detail(String label, String value, Color valueColor) => Column(children: [
    Text(label,
        style: TextStyle(
            fontSize: 9,
            color: Colors.grey.shade400,
            letterSpacing: 0.8,
            fontWeight: FontWeight.w600)),
    const SizedBox(height: 2),
    Text(value,
        style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: valueColor),
        overflow: TextOverflow.ellipsis,
        textAlign: TextAlign.center),
  ]);

  Widget _divider() => Container(
      height: 28,
      width: 1,
      color: Colors.grey.shade200,
      margin: const EdgeInsets.symmetric(horizontal: 4));

  Widget _exportBar() => Container(
    padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
    decoration: BoxDecoration(
        color: kNavy, border: Border(top: BorderSide(color: Colors.white.withOpacity(0.08)))),
    child: SafeArea(
      top: false,
      child: Row(children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: _busy ? null : _previewPdf,
            icon: const Icon(Icons.visibility_rounded, size: 16, color: Colors.white),
            label: const Text('Preview', style: TextStyle(color: Colors.white)),
            style: OutlinedButton.styleFrom(
                side: BorderSide(color: Colors.white.withOpacity(0.2)),
                padding: const EdgeInsets.symmetric(vertical: 12)),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: _busy ? null : () => _export(pdf: true),
            icon: const Icon(Icons.picture_as_pdf_rounded, size: 16),
            label: const Text('PDF'),
            style: ElevatedButton.styleFrom(
                backgroundColor: kTeal,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 12)),
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: _busy ? null : () => _export(pdf: false),
            icon: const Icon(Icons.grid_on_rounded, size: 16),
            label: const Text('Excel'),
            style: ElevatedButton.styleFrom(
                backgroundColor: kGreen,
                foregroundColor: Colors.white,
                elevation: 0,
                padding: const EdgeInsets.symmetric(vertical: 12)),
          ),
        ),
      ]),
    ),
  );

  Widget _errorState() => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Icon(Icons.cloud_off_rounded, color: kCoral, size: 40),
        const SizedBox(height: 12),
        Text(_error!, style: TextStyle(color: Colors.grey.shade600), textAlign: TextAlign.center),
        const SizedBox(height: 12),
        ElevatedButton(
          onPressed: _load,
          style: ElevatedButton.styleFrom(
              backgroundColor: kNavy,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
          child: const Text('Retry'),
        ),
      ]),
    ),
  );

  Widget _emptyState() => Center(
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(Icons.history_toggle_off_rounded, size: 56, color: Colors.grey.shade300),
      const SizedBox(height: 10),
      Text('No stock transactions in ${DateFormat('MMMM yyyy').format(_month)}',
          style: TextStyle(color: Colors.grey.shade500)),
    ]),
  );
}