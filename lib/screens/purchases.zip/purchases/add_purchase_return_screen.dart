import 'package:flutter/material.dart';
import 'package:cda_inventory/models/purchase_return.dart';
import 'package:cda_inventory/services/purchase_return_service.dart';
import 'package:cda_inventory/shared/inventory_ui.dart';

class AddPurchaseReturnScreen extends StatefulWidget {
  const AddPurchaseReturnScreen({super.key});

  @override
  State<AddPurchaseReturnScreen> createState() => _AddPurchaseReturnScreenState();
}

class _AddPurchaseReturnScreenState extends State<AddPurchaseReturnScreen> {
  final _formKey = GlobalKey<FormState>();
  final productController = TextEditingController();
  final vendorController = TextEditingController();
  final quantityController = TextEditingController();
  final amountController = TextEditingController();
  final referenceInvoiceController = TextEditingController();
  final dateController = TextEditingController();

  String selectedBranch = kBranches.first;
  String selectedReason = 'Damaged Goods';
  bool _isLoading = false;

  static const reasons = [
    'Damaged Goods',
    'Wrong Item Delivered',
    'Excess Quantity',
    'Quality Issue',
    'Expired Product',
    'Other',
  ];

  @override
  void dispose() {
    productController.dispose();
    vendorController.dispose();
    quantityController.dispose();
    amountController.dispose();
    referenceInvoiceController.dispose();
    dateController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2024),
      lastDate: DateTime(2030),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
            colorScheme:
            const ColorScheme.light(primary: AppColors.navy, onPrimary: Colors.white)),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        dateController.text =
        '${picked.day.toString().padLeft(2, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.year}';
      });
    }
  }

  void _clearForm() {
    productController.clear();
    vendorController.clear();
    quantityController.clear();
    amountController.clear();
    referenceInvoiceController.clear();
    dateController.clear();
    setState(() {
      selectedBranch = kBranches.first;
      selectedReason = 'Damaged Goods';
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (dateController.text.isEmpty) {
      showAppSnack(context, 'Please select a return date', isError: true);
      return;
    }
    setState(() => _isLoading = true);

    final ret = PurchaseReturn(
      productName: productController.text.trim(),
      vendorName: vendorController.text.trim(),
      quantity: int.parse(quantityController.text.trim()),
      amount: double.parse(amountController.text.trim()),
      reason: selectedReason,
      referenceInvoice: referenceInvoiceController.text.trim(),
      branch: selectedBranch,
      returnDate: dateController.text.trim(),
    );

    final result = await PurchaseReturnService.addPurchaseReturn(ret);
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (result['success'] == true) {
      showSuccessDialog(
        context,
        title: 'Return Recorded!',
        message: 'The purchase return / debit note has been recorded successfully.',
        onAddMore: _clearForm,
        onViewList: () => Navigator.pop(context, true),
      );
    } else {
      showAppSnack(context, result['message'] ?? 'Something went wrong', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded, size: 20),
            onPressed: () => Navigator.pop(context)),
        title: const Text('Purchase Return / Dr. Note',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Clear form',
              onPressed: _isLoading ? null : _clearForm),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const HeroBanner(
                icon: Icons.keyboard_return_rounded,
                title: 'New Purchase Return',
                subtitle: 'Record goods returned to a vendor',
              ),
              const SizedBox(height: 24),
              const SectionLabel('PRODUCT & VENDOR'),
              const SizedBox(height: 10),
              FormCard(children: [
                AppTextField(
                  controller: productController,
                  label: 'Product Name',
                  hint: 'e.g. A4 Sheets, Drone Battery',
                  icon: Icons.inventory_2_rounded,
                  capitalization: TextCapitalization.words,
                  validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Product name is required' : null,
                ),
                const SizedBox(height: 14),
                AppTextField(
                  controller: vendorController,
                  label: 'Vendor Name',
                  hint: 'e.g. ABC Stationery',
                  icon: Icons.storefront_rounded,
                  capitalization: TextCapitalization.words,
                  validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Vendor name is required' : null,
                ),
              ]),
              const SizedBox(height: 20),
              const SectionLabel('RETURN DETAILS'),
              const SizedBox(height: 10),
              FormCard(children: [
                Row(children: [
                  Expanded(
                    child: AppTextField(
                      controller: quantityController,
                      label: 'Quantity',
                      hint: '0',
                      icon: Icons.format_list_numbered_rounded,
                      keyboardType: TextInputType.number,
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Required';
                        if (int.tryParse(v.trim()) == null) return 'Numbers only';
                        if (int.parse(v.trim()) <= 0) return 'Must be > 0';
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: AppTextField(
                      controller: amountController,
                      label: 'Amount (₹)',
                      hint: '0.00',
                      icon: Icons.currency_rupee_rounded,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Required';
                        if (double.tryParse(v.trim()) == null) return 'Numbers only';
                        if (double.parse(v.trim()) <= 0) return 'Must be > 0';
                        return null;
                      },
                    ),
                  ),
                ]),
                const SizedBox(height: 14),
                AppDropdown(
                  value: selectedReason,
                  label: 'Reason for Return',
                  icon: Icons.report_problem_rounded,
                  items: reasons,
                  onChanged: (v) => setState(() => selectedReason = v!),
                ),
                const SizedBox(height: 14),
                AppTextField(
                  controller: referenceInvoiceController,
                  label: 'Reference Invoice Number',
                  hint: 'e.g. INV-2025-001 (optional)',
                  icon: Icons.receipt_long_rounded,
                ),
              ]),
              const SizedBox(height: 20),
              const SectionLabel('BRANCH & DATE'),
              const SizedBox(height: 10),
              FormCard(children: [
                AppDropdown(
                  value: selectedBranch,
                  label: 'Branch',
                  icon: Icons.location_city_rounded,
                  items: kBranches,
                  onChanged: (v) => setState(() => selectedBranch = v!),
                ),
                const SizedBox(height: 14),
                AppDatePickerField(
                  value: dateController.text,
                  placeholder: 'Select Return Date',
                  onTap: _pickDate,
                ),
              ]),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.navy,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: Colors.grey.shade200,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                  child: _isLoading
                      ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                      : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.save_rounded, size: 20),
                      SizedBox(width: 8),
                      Text('Save Return',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}