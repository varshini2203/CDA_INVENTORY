import 'package:flutter/material.dart';
import 'package:cda_inventory/models/purchase_order.dart';
import 'package:cda_inventory/services/purchase_order_service.dart';
import 'package:cda_inventory/shared/inventory_ui.dart';

class AddPurchaseOrderScreen extends StatefulWidget {
  const AddPurchaseOrderScreen({super.key});

  @override
  State<AddPurchaseOrderScreen> createState() => _AddPurchaseOrderScreenState();
}

class _AddPurchaseOrderScreenState extends State<AddPurchaseOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  final productController = TextEditingController();
  final vendorController = TextEditingController();
  final quantityController = TextEditingController();
  final costController = TextEditingController();
  final notesController = TextEditingController();
  final orderDateController = TextEditingController();
  final deliveryDateController = TextEditingController();

  String selectedBranch = kBranches.first;
  bool _isLoading = false;

  @override
  void dispose() {
    productController.dispose();
    vendorController.dispose();
    quantityController.dispose();
    costController.dispose();
    notesController.dispose();
    orderDateController.dispose();
    deliveryDateController.dispose();
    super.dispose();
  }

  Future<void> _pickDate(TextEditingController controller) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2024),
      lastDate: DateTime(2031),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
            colorScheme:
            const ColorScheme.light(primary: AppColors.navy, onPrimary: Colors.white)),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        controller.text =
        '${picked.day.toString().padLeft(2, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.year}';
      });
    }
  }

  void _clearForm() {
    productController.clear();
    vendorController.clear();
    quantityController.clear();
    costController.clear();
    notesController.clear();
    orderDateController.clear();
    deliveryDateController.clear();
    setState(() => selectedBranch = kBranches.first);
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (orderDateController.text.isEmpty) {
      showAppSnack(context, 'Please select an order date', isError: true);
      return;
    }
    setState(() => _isLoading = true);

    final order = PurchaseOrder(
      productName: productController.text.trim(),
      vendorName: vendorController.text.trim(),
      quantity: int.parse(quantityController.text.trim()),
      expectedCost: double.parse(costController.text.trim()),
      branch: selectedBranch,
      orderDate: orderDateController.text.trim(),
      expectedDeliveryDate: deliveryDateController.text.trim(),
      notes: notesController.text.trim(),
    );

    final result = await PurchaseOrderService.addPurchaseOrder(order);
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (result['success'] == true) {
      showSuccessDialog(
        context,
        title: 'Purchase Order Created!',
        message: 'The purchase order has been recorded successfully.',
        onAddMore: _clearForm,
        onViewList: () => Navigator.pop(context, true),
      );
    } else {
      showAppSnack(context, result['message'] ?? 'Something went wrong', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded, size: 20),
            onPressed: () => Navigator.pop(context)),
        title: const Text('Purchase Order',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Clear form',
              onPressed: _isLoading ? null : _clearForm),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const HeroBanner(
                icon: Icons.assignment_rounded,
                title: 'New Purchase Order',
                subtitle: 'Place an order with a vendor',
              ),
              const SizedBox(height: 24),
              const SectionLabel('PRODUCT & VENDOR'),
              const SizedBox(height: 10),
              FormCard(children: [
                AppTextField(
                  controller: productController,
                  label: 'Product Name',
                  hint: 'e.g. A4 Sheets, Drone Battery',
                  icon: Icons.inventory_2_rounded,
                  capitalization: TextCapitalization.words,
                  validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Product name is required' : null,
                ),
                const SizedBox(height: 14),
                AppTextField(
                  controller: vendorController,
                  label: 'Vendor Name',
                  hint: 'e.g. ABC Stationery',
                  icon: Icons.storefront_rounded,
                  capitalization: TextCapitalization.words,
                  validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Vendor name is required' : null,
                ),
              ]),
              const SizedBox(height: 20),
              const SectionLabel('ORDER DETAILS'),
              const SizedBox(height: 10),
              FormCard(children: [
                Row(children: [
                  Expanded(
                    child: AppTextField(
                      controller: quantityController,
                      label: 'Quantity',
                      hint: '0',
                      icon: Icons.format_list_numbered_rounded,
                      keyboardType: TextInputType.number,
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Required';
                        if (int.tryParse(v.trim()) == null) return 'Numbers only';
                        if (int.parse(v.trim()) <= 0) return 'Must be > 0';
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: AppTextField(
                      controller: costController,
                      label: 'Expected Cost (₹)',
                      hint: '0.00',
                      icon: Icons.currency_rupee_rounded,
                      keyboardType: const TextInputType.numberWithOptions(decimal: true),
                      validator: (v) {
                        if (v == null || v.trim().isEmpty) return 'Required';
                        if (double.tryParse(v.trim()) == null) return 'Numbers only';
                        if (double.parse(v.trim()) <= 0) return 'Must be > 0';
                        return null;
                      },
                    ),
                  ),
                ]),
              ]),
              const SizedBox(height: 20),
              const SectionLabel('BRANCH & DATES'),
              const SizedBox(height: 10),
              FormCard(children: [
                AppDropdown(
                  value: selectedBranch,
                  label: 'Branch',
                  icon: Icons.location_city_rounded,
                  items: kBranches,
                  onChanged: (v) => setState(() => selectedBranch = v!),
                ),
                const SizedBox(height: 14),
                AppDatePickerField(
                  value: orderDateController.text,
                  placeholder: 'Select Order Date',
                  onTap: () => _pickDate(orderDateController),
                ),
                const SizedBox(height: 14),
                AppDatePickerField(
                  value: deliveryDateController.text,
                  placeholder: 'Expected Delivery Date (optional)',
                  onTap: () => _pickDate(deliveryDateController),
                ),
              ]),
              const SizedBox(height: 20),
              const SectionLabel('NOTES (OPTIONAL)'),
              const SizedBox(height: 10),
              FormCard(children: [
                AppTextField(
                  controller: notesController,
                  label: 'Notes',
                  hint: 'Any additional details',
                  icon: Icons.notes_rounded,
                  maxLines: 3,
                ),
              ]),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.navy,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: Colors.grey.shade200,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                  child: _isLoading
                      ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                      : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.save_rounded, size: 20),
                      SizedBox(width: 8),
                      Text('Save Order',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}