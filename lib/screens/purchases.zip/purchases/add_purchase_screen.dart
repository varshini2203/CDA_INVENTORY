import 'package:flutter/material.dart';
import 'package:cda_inventory/models/purchase.dart';
import 'package:cda_inventory/services/purchase_service.dart';

class AddPurchaseScreen extends StatefulWidget {
  const AddPurchaseScreen({super.key});

  @override
  State<AddPurchaseScreen> createState() => _AddPurchaseScreenState();
}

class _AddPurchaseScreenState extends State<AddPurchaseScreen>
    with SingleTickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController productController   = TextEditingController();
  final TextEditingController vendorController    = TextEditingController();
  final TextEditingController quantityController  = TextEditingController();
  final TextEditingController costController      = TextEditingController();
  final TextEditingController invoiceController   = TextEditingController();
  final TextEditingController dateController      = TextEditingController();

  String selectedBranch = "Branch 1";
  bool _isLoading = false;

  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  // ── Design tokens (matches Invoice & Consumable screens) ──────────────────
  static const Color kNavy    = Color(0xFF0A1628);
  static const Color kTeal    = Color(0xFF00D4AA);
  static const Color kCoral   = Color(0xFFFF6B6B);
  static const Color kAmber   = Color(0xFFFFB800);
  static const Color kSurface = Color(0xFFF0F4F8);
  static const Color kGreen   = Color(0xFF00B894);

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeOut);
    _animController.forward();
    quantityController.addListener(() => setState(() {}));
    costController.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _animController.dispose();
    productController.dispose();
    vendorController.dispose();
    quantityController.dispose();
    costController.dispose();
    invoiceController.dispose();
    dateController.dispose();
    super.dispose();
  }

  double get _estimatedTotal {
    final qty  = int.tryParse(quantityController.text) ?? 0;
    final cost = double.tryParse(costController.text) ?? 0.0;
    return qty * cost;
  }

  bool get _showTotal =>
      quantityController.text.isNotEmpty && costController.text.isNotEmpty;

  Future<void> _savePurchase() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isLoading = true);

    final purchase = Purchase(
      productName:   productController.text.trim(),
      vendorName:    vendorController.text.trim(),
      quantity:      int.parse(quantityController.text.trim()),
      cost:          double.parse(costController.text.trim()),
      invoiceNumber: invoiceController.text.trim(),
      branch:        selectedBranch,
      purchaseDate:  dateController.text.trim(),
    );

    final result = await PurchaseService.addPurchase(purchase);
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (result['success'] == true) {
      _showSuccessDialog();
    } else {
      _showSnack(result['message'] ?? 'Something went wrong', isError: true);
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: kGreen.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.check_circle_rounded,
                    color: kGreen, size: 52),
              ),
              const SizedBox(height: 20),
              const Text(
                'Purchase Saved!',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: kNavy),
              ),
              const SizedBox(height: 8),
              Text(
                'The purchase has been recorded successfully.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey.shade600, fontSize: 14),
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        _clearForm();
                      },
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        foregroundColor: kNavy,
                        side: const BorderSide(color: kNavy),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('Add More'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pop(context);
                        Navigator.pop(context, true);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: kNavy,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text('View List'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(
            isError ? Icons.error_outline : Icons.check_circle_outline,
            color: Colors.white,
            size: 18,
          ),
          const SizedBox(width: 8),
          Expanded(child: Text(msg)),
        ]),
        backgroundColor: isError ? kCoral : kGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  void _clearForm() {
    productController.clear();
    vendorController.clear();
    quantityController.clear();
    costController.clear();
    invoiceController.clear();
    dateController.clear();
    setState(() => selectedBranch = 'Branch 1');
  }

  Future<void> _pickDate() async {
    FocusScope.of(context).requestFocus(FocusNode());
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2024),
      lastDate: DateTime(2030),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(
              primary: kNavy, onPrimary: Colors.white),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      dateController.text =
      '${picked.day.toString().padLeft(2, '0')}-'
          '${picked.month.toString().padLeft(2, '0')}-'
          '${picked.year}';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSurface,
      appBar: AppBar(
        backgroundColor: kNavy,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, size: 20),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          'Add Purchase',
          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Clear form',
            onPressed: _isLoading ? null : _clearForm,
          ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // ── Hero banner ─────────────────────────────────────────────
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [const Color(0xFF00B894), kTeal],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration: BoxDecoration(
                          color: Colors.white.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(14),
                        ),
                        child: const Icon(Icons.add_shopping_cart_rounded,
                            color: Colors.white, size: 28),
                      ),
                      const SizedBox(width: 16),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'New Purchase Entry',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w800,
                              fontSize: 18,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            'Fill details to record a purchase',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.8),
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                // ── Product Information ──────────────────────────────────────
                _sectionLabel('PRODUCT INFORMATION'),
                const SizedBox(height: 10),
                _card(children: [
                  _field(
                    controller: productController,
                    label: 'Product Name',
                    hint: 'e.g. A4 Sheets, Drone Battery',
                    icon: Icons.inventory_2_rounded,
                    capitalization: TextCapitalization.words,
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Product name is required'
                        : null,
                  ),
                  const SizedBox(height: 14),
                  _field(
                    controller: vendorController,
                    label: 'Vendor Name',
                    hint: 'e.g. ABC Stationery',
                    icon: Icons.storefront_rounded,
                    capitalization: TextCapitalization.words,
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Vendor name is required'
                        : null,
                  ),
                ]),

                const SizedBox(height: 20),

                // ── Purchase Details ─────────────────────────────────────────
                _sectionLabel('PURCHASE DETAILS'),
                const SizedBox(height: 10),
                _card(children: [
                  Row(children: [
                    Expanded(
                      child: _field(
                        controller: quantityController,
                        label: 'Quantity',
                        hint: '0',
                        icon: Icons.format_list_numbered_rounded,
                        keyboardType: TextInputType.number,
                        validator: (v) {
                          if (v == null || v.trim().isEmpty) return 'Required';
                          if (int.tryParse(v.trim()) == null) return 'Numbers only';
                          if (int.parse(v.trim()) <= 0) return 'Must be > 0';
                          return null;
                        },
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: _field(
                        controller: costController,
                        label: 'Cost (₹)',
                        hint: '0.00',
                        icon: Icons.currency_rupee_rounded,
                        keyboardType: const TextInputType.numberWithOptions(decimal: true),
                        validator: (v) {
                          if (v == null || v.trim().isEmpty) return 'Required';
                          if (double.tryParse(v.trim()) == null) return 'Numbers only';
                          if (double.parse(v.trim()) <= 0) return 'Must be > 0';
                          return null;
                        },
                      ),
                    ),
                  ]),
                  const SizedBox(height: 14),
                  _field(
                    controller: invoiceController,
                    label: 'Invoice Number',
                    hint: 'e.g. INV-2025-001',
                    icon: Icons.receipt_long_rounded,
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Invoice number is required'
                        : null,
                  ),
                ]),

                const SizedBox(height: 20),

                // ── Branch & Date ────────────────────────────────────────────
                _sectionLabel('BRANCH & DATE'),
                const SizedBox(height: 10),
                _card(children: [
                  // Branch dropdown
                  DropdownButtonFormField<String>(
                    value: selectedBranch,
                    style: const TextStyle(
                        color: kNavy, fontWeight: FontWeight.w500, fontSize: 15),
                    dropdownColor: Colors.white,
                    decoration: InputDecoration(
                      labelText: 'Branch',
                      labelStyle:
                      TextStyle(color: Colors.grey.shade500, fontSize: 14),
                      prefixIcon: Icon(Icons.location_city_rounded,
                          size: 20, color: Colors.grey.shade400),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey.shade200),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide(color: Colors.grey.shade200),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: kTeal, width: 1.5),
                      ),
                      filled: true,
                      fillColor: Colors.grey.shade50,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 14),
                    ),
                    items: ['Branch 1', 'Branch 2', 'Branch 3']
                        .map((b) => DropdownMenuItem(value: b, child: Text(b)))
                        .toList(),
                    onChanged: (value) => setState(() => selectedBranch = value!),
                  ),
                  const SizedBox(height: 14),
                  // Date picker
                  GestureDetector(
                    onTap: _pickDate,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 14),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade50,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(
                          color: dateController.text.isNotEmpty
                              ? kTeal
                              : Colors.grey.shade200,
                          width: dateController.text.isNotEmpty ? 1.5 : 1,
                        ),
                      ),
                      child: Row(
                        children: [
                          Icon(
                            Icons.calendar_today_rounded,
                            size: 20,
                            color: dateController.text.isNotEmpty
                                ? kTeal
                                : Colors.grey.shade400,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              dateController.text.isNotEmpty
                                  ? dateController.text
                                  : 'Select Purchase Date',
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: dateController.text.isNotEmpty
                                    ? FontWeight.w500
                                    : FontWeight.w400,
                                color: dateController.text.isNotEmpty
                                    ? kNavy
                                    : Colors.grey.shade500,
                              ),
                            ),
                          ),
                          Icon(Icons.arrow_forward_ios_rounded,
                              size: 14, color: Colors.grey.shade400),
                        ],
                      ),
                    ),
                  ),
                  // Hidden validator for date
                  TextFormField(
                    controller: dateController,
                    readOnly: true,
                    style: const TextStyle(height: 0),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.zero,
                      isDense: true,
                    ),
                    validator: (v) => (v == null || v.trim().isEmpty)
                        ? 'Purchase date is required'
                        : null,
                  ),
                ]),

                // ── Live total preview ───────────────────────────────────────
                AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: _showTotal
                      ? Padding(
                    key: const ValueKey('total'),
                    padding: const EdgeInsets.only(top: 16),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 16, vertical: 14),
                      decoration: BoxDecoration(
                        color: kNavy,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.calculate_rounded,
                              color: kTeal, size: 22),
                          const SizedBox(width: 12),
                          const Text('Estimated Total',
                              style: TextStyle(
                                  color: Colors.white70, fontSize: 14)),
                          const Spacer(),
                          Text(
                            '₹${_estimatedTotal.toStringAsFixed(2)}',
                            style: const TextStyle(
                              color: kTeal,
                              fontWeight: FontWeight.w800,
                              fontSize: 20,
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                      : const SizedBox.shrink(key: ValueKey('empty')),
                ),

                const SizedBox(height: 28),

                // ── Save button ──────────────────────────────────────────────
                SizedBox(
                  width: double.infinity,
                  height: 54,
                  child: ElevatedButton(
                    onPressed: _isLoading ? null : _savePurchase,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kNavy,
                      foregroundColor: Colors.white,
                      disabledBackgroundColor: Colors.grey.shade200,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      elevation: 0,
                    ),
                    child: _isLoading
                        ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(
                          strokeWidth: 2.5, color: Colors.white),
                    )
                        : const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.save_rounded, size: 20),
                        SizedBox(width: 8),
                        Text(
                          'Save Purchase',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w700),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _sectionLabel(String text) {
    return Text(
      text,
      style: TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w700,
        color: Colors.grey.shade500,
        letterSpacing: 1.4,
      ),
    );
  }

  Widget _card({required List<Widget> children}) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: children),
    );
  }

  Widget _field({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    String? hint,
    TextInputType keyboardType = TextInputType.text,
    TextCapitalization capitalization = TextCapitalization.none,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      textCapitalization: capitalization,
      style: const TextStyle(
          fontSize: 15, fontWeight: FontWeight.w500, color: kNavy),
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        labelStyle: TextStyle(color: Colors.grey.shade500, fontSize: 14),
        hintStyle: TextStyle(color: Colors.grey.shade300, fontSize: 14),
        prefixIcon: Icon(icon, size: 20, color: Colors.grey.shade400),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey.shade200),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: kTeal, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: kCoral),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: kCoral, width: 1.5),
        ),
        filled: true,
        fillColor: Colors.grey.shade50,
        contentPadding:
        const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
      ),
      validator: validator,
    );
  }
}