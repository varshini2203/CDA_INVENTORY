import 'package:flutter/material.dart';
import 'package:cda_inventory/models/payment_out.dart';
import 'package:cda_inventory/services/payment_out_service.dart';
import 'package:cda_inventory/shared/inventory_ui.dart';

class AddPaymentOutScreen extends StatefulWidget {
  const AddPaymentOutScreen({super.key});

  @override
  State<AddPaymentOutScreen> createState() => _AddPaymentOutScreenState();
}

class _AddPaymentOutScreenState extends State<AddPaymentOutScreen> {
  final _formKey = GlobalKey<FormState>();
  final vendorController = TextEditingController();
  final amountController = TextEditingController();
  final referenceController = TextEditingController();
  final notesController = TextEditingController();
  final dateController = TextEditingController();

  String selectedBranch = kBranches.first;
  String selectedMode = 'Cash';
  bool _isLoading = false;

  static const modes = ['Cash', 'Bank Transfer', 'UPI', 'Cheque'];

  @override
  void dispose() {
    vendorController.dispose();
    amountController.dispose();
    referenceController.dispose();
    notesController.dispose();
    dateController.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2024),
      lastDate: DateTime(2030),
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
            colorScheme:
            const ColorScheme.light(primary: AppColors.navy, onPrimary: Colors.white)),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() {
        dateController.text =
        '${picked.day.toString().padLeft(2, '0')}-${picked.month.toString().padLeft(2, '0')}-${picked.year}';
      });
    }
  }

  void _clearForm() {
    vendorController.clear();
    amountController.clear();
    referenceController.clear();
    notesController.clear();
    dateController.clear();
    setState(() {
      selectedBranch = kBranches.first;
      selectedMode = 'Cash';
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (dateController.text.isEmpty) {
      showAppSnack(context, 'Please select a payment date', isError: true);
      return;
    }
    setState(() => _isLoading = true);

    final payment = PaymentOut(
      vendorName: vendorController.text.trim(),
      amount: double.parse(amountController.text.trim()),
      paymentMode: selectedMode,
      referenceNumber: referenceController.text.trim(),
      branch: selectedBranch,
      paymentDate: dateController.text.trim(),
      notes: notesController.text.trim(),
    );

    final result = await PaymentOutService.addPaymentOut(payment);
    if (!mounted) return;
    setState(() => _isLoading = false);

    if (result['success'] == true) {
      showSuccessDialog(
        context,
        title: 'Payment Recorded!',
        message: 'The payment-out has been recorded successfully.',
        onAddMore: _clearForm,
        onViewList: () => Navigator.pop(context, true),
      );
    } else {
      showAppSnack(context, result['message'] ?? 'Something went wrong', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
            icon: const Icon(Icons.arrow_back_ios_rounded, size: 20),
            onPressed: () => Navigator.pop(context)),
        title: const Text('Payment-Out',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh_rounded),
              tooltip: 'Clear form',
              onPressed: _isLoading ? null : _clearForm),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const HeroBanner(
                icon: Icons.payments_rounded,
                title: 'New Payment-Out',
                subtitle: 'Record a payment made to a vendor',
              ),
              const SizedBox(height: 24),
              const SectionLabel('PAYMENT DETAILS'),
              const SizedBox(height: 10),
              FormCard(children: [
                AppTextField(
                  controller: vendorController,
                  label: 'Vendor Name',
                  hint: 'e.g. ABC Stationery',
                  icon: Icons.storefront_rounded,
                  capitalization: TextCapitalization.words,
                  validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Vendor name is required' : null,
                ),
                const SizedBox(height: 14),
                AppTextField(
                  controller: amountController,
                  label: 'Amount (₹)',
                  hint: '0.00',
                  icon: Icons.currency_rupee_rounded,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  validator: (v) {
                    if (v == null || v.trim().isEmpty) return 'Required';
                    if (double.tryParse(v.trim()) == null) return 'Numbers only';
                    if (double.parse(v.trim()) <= 0) return 'Must be > 0';
                    return null;
                  },
                ),
                const SizedBox(height: 14),
                AppDropdown(
                  value: selectedMode,
                  label: 'Payment Mode',
                  icon: Icons.account_balance_wallet_rounded,
                  items: modes,
                  onChanged: (v) => setState(() => selectedMode = v!),
                ),
                const SizedBox(height: 14),
                AppTextField(
                  controller: referenceController,
                  label: 'Reference Number',
                  hint: 'e.g. TXN12345 (optional)',
                  icon: Icons.receipt_long_rounded,
                ),
              ]),
              const SizedBox(height: 20),
              const SectionLabel('BRANCH & DATE'),
              const SizedBox(height: 10),
              FormCard(children: [
                AppDropdown(
                  value: selectedBranch,
                  label: 'Branch',
                  icon: Icons.location_city_rounded,
                  items: kBranches,
                  onChanged: (v) => setState(() => selectedBranch = v!),
                ),
                const SizedBox(height: 14),
                AppDatePickerField(
                  value: dateController.text,
                  placeholder: 'Select Payment Date',
                  onTap: _pickDate,
                ),
              ]),
              const SizedBox(height: 20),
              const SectionLabel('NOTES (OPTIONAL)'),
              const SizedBox(height: 10),
              FormCard(children: [
                AppTextField(
                  controller: notesController,
                  label: 'Notes',
                  hint: 'Any additional details',
                  icon: Icons.notes_rounded,
                  maxLines: 3,
                ),
              ]),
              const SizedBox(height: 28),
              SizedBox(
                width: double.infinity,
                height: 54,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _save,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.navy,
                    foregroundColor: Colors.white,
                    disabledBackgroundColor: Colors.grey.shade200,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                  child: _isLoading
                      ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white))
                      : const Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.save_rounded, size: 20),
                      SizedBox(width: 8),
                      Text('Save Payment',
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }
}