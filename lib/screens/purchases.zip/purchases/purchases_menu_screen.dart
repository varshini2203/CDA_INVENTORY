import 'package:flutter/material.dart';
import 'package:cda_inventory/shared/inventory_ui.dart';
import 'purchase_list_screen.dart';
import 'purchase_order_list_screen.dart';
import 'payment_out_list_screen.dart';
import 'purchase_return_list_screen.dart';

/// Hub screen shown from the main Dashboard's "Purchases" tile.
/// Routes into the four purchase sub-modules: Purchases, Purchase Orders,
/// Payment Out, and Purchase Returns.
class PurchasesMenuScreen extends StatefulWidget {
  const PurchasesMenuScreen({super.key});

  @override
  State<PurchasesMenuScreen> createState() => _PurchasesMenuScreenState();
}

class _PurchasesMenuScreenState extends State<PurchasesMenuScreen> {
  String _query = '';

  // TODO: wire these up to your real data source (provider / repository).
  // Kept as simple fields so the UI is functional out of the box; replace
  // the hardcoded numbers with values from your purchases repository.
  final int _purchasesThisMonth = 18;
  final double _payableToVendors = 42500;
  final int _pendingOrders = 5;
  final int _returnsThisMonth = 2;

  Future<void> _refresh() async {
    // TODO: hook this up to actually reload summary counts from your
    // repository/provider. Kept as a short delay so pull-to-refresh works.
    await Future.delayed(const Duration(milliseconds: 500));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final allTiles = <_MenuTile>[
      _MenuTile(
        title: 'Purchases',
        subtitle: 'Record stock bought in',
        icon: Icons.shopping_bag_rounded,
        color: AppColors.navy,
        badgeCount: _purchasesThisMonth,
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const PurchaseListScreen())),
      ),
      _MenuTile(
        title: 'Purchase Orders',
        subtitle: 'Orders placed with vendors',
        icon: Icons.assignment_rounded,
        color: const Color(0xFF6C63FF),
        badgeCount: _pendingOrders,
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const PurchaseOrderListScreen())),
      ),
      _MenuTile(
        title: 'Payment Out',
        subtitle: 'Payments made to vendors',
        icon: Icons.payments_rounded,
        color: const Color(0xFF00B894),
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const PaymentOutListScreen())),
      ),
      _MenuTile(
        title: 'Purchase Returns',
        subtitle: 'Goods returned to vendors',
        icon: Icons.assignment_return_rounded,
        color: const Color(0xFFFF6B6B),
        badgeCount: _returnsThisMonth,
        onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const PurchaseReturnListScreen())),
      ),
    ];

    final tiles = _query.isEmpty
        ? allTiles
        : allTiles
        .where((t) =>
    t.title.toLowerCase().contains(_query.toLowerCase()) ||
        t.subtitle.toLowerCase().contains(_query.toLowerCase()))
        .toList();

    return Scaffold(
      backgroundColor: AppColors.surface,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text('Purchases',
            style: TextStyle(fontWeight: FontWeight.w700, fontSize: 18)),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.navy,
        icon: const Icon(Icons.add),
        label: const Text('New Purchase'),
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const PurchaseListScreen())),
      ),
      body: RefreshIndicator(
        onRefresh: _refresh,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const HeroBanner(
              icon: Icons.storefront_rounded,
              title: 'Purchases Hub',
              subtitle: 'Manage everything you buy from vendors',
            ),
            const SizedBox(height: 16),

            // Quick stats row
            Row(
              children: [
                Expanded(
                  child: _StatCard(
                    label: 'This Month',
                    value: '$_purchasesThisMonth',
                    icon: Icons.receipt_long_rounded,
                    color: AppColors.navy,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _StatCard(
                    label: 'Payable',
                    value: '\u20b9${_payableToVendors.toStringAsFixed(0)}',
                    icon: Icons.account_balance_wallet_rounded,
                    color: const Color(0xFF00B894),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Search / filter
            TextField(
              onChanged: (v) => setState(() => _query = v),
              decoration: InputDecoration(
                hintText: 'Search purchase modules...',
                prefixIcon: const Icon(Icons.search_rounded, size: 20),
                filled: true,
                fillColor: Colors.white,
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.black.withValues(alpha: 0.08)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide(color: Colors.black.withValues(alpha: 0.08)),
                ),
              ),
            ),
            const SizedBox(height: 16),

            if (tiles.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 40),
                child: Center(
                  child: Text('No modules match "$_query"',
                      style: TextStyle(color: Colors.grey.shade600)),
                ),
              )
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  maxCrossAxisExtent: 210, // caps card width so it never balloons
                  mainAxisExtent: 140, // fixed, compact card height
                  mainAxisSpacing: 14,
                  crossAxisSpacing: 14,
                ),
                itemCount: tiles.length,
                itemBuilder: (context, index) => tiles[index],
              ),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;

  const _StatCard({
    required this.label,
    required this.value,
    required this.icon,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.black.withValues(alpha: 0.06)),
      ),
      child: Row(
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Icon(icon, color: color, size: 18),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(value,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF1A2138))),
                Text(label,
                    style: TextStyle(fontSize: 11, color: Colors.grey.shade600)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  final int? badgeCount;

  const _MenuTile({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.color,
    required this.onTap,
    this.badgeCount,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.black.withValues(alpha: 0.06)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.04),
                blurRadius: 10,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    width: 38,
                    height: 38,
                    decoration: BoxDecoration(
                      color: color.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: Icon(icon, color: color, size: 20),
                  ),
                  if (badgeCount != null && badgeCount! > 0)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.12),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text('$badgeCount',
                          style: TextStyle(
                              fontSize: 11, fontWeight: FontWeight.w700, color: color)),
                    ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(title,
                      style: const TextStyle(
                          fontSize: 14, fontWeight: FontWeight.w700, color: Color(0xFF1A2138))),
                  const SizedBox(height: 2),
                  Text(subtitle,
                      style: TextStyle(fontSize: 11.5, color: Colors.grey.shade600),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}