// lib/screens/reports/reports_dashboard_screen.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'drone_inout_report_screen.dart';
import 'invoice_report_screen.dart';
import 'stock_history_report_screen.dart';
import 'package:cda_inventory/services/report_service.dart';
import 'package:cda_inventory/services/excel_export_service.dart'
    hide MonthlySummary, DroneReportRow, ReportService;
import 'package:cda_inventory/services/pdf_export_service.dart';
class ReportsDashboardScreen extends StatefulWidget {
  const ReportsDashboardScreen({super.key});

  @override
  State<ReportsDashboardScreen> createState() => _ReportsDashboardScreenState();
}

class _ReportsDashboardScreenState extends State<ReportsDashboardScreen>
    with SingleTickerProviderStateMixin {
  DateTime _selectedMonth = DateTime(DateTime.now().year, DateTime.now().month);
  MonthlySummary? _summary;
  bool _loading = true;
  // Tracks which export is currently running ('pdf', 'excel', or null when idle)
  // so only the clicked button shows its spinner instead of both.
  String? _exportingType;
  String? _error;

  late AnimationController _animController;
  late Animation<double> _fadeAnim;

  // ── Design tokens (matches Invoice List screen theme) ──────────────────────
  static const Color kNavy = Color(0xFF0A1628);
  static const Color kTeal = Color(0xFF00D4AA);
  static const Color kCoral = Color(0xFFFF6B6B);
  static const Color kAmber = Color(0xFFFFB800);
  static const Color kSurface = Color(0xFFF0F4F8);
  static const Color kGreen = Color(0xFF00B894);
  static const Color kPurple = Color(0xFF6C63FF);

  @override
  void initState() {
    super.initState();
    _animController =
        AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _fadeAnim = CurvedAnimation(parent: _animController, curve: Curves.easeOut);
    _loadSummary();
  }

  @override
  void dispose() {
    _animController.dispose();
    super.dispose();
  }

  Future<void> _loadSummary() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    try {
      final s = await ReportService.fetchMonthlySummary(
          _selectedMonth.year, _selectedMonth.month);
      setState(() {
        _summary = s;
        _loading = false;
      });
      _animController.forward(from: 0);
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _pickMonth() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: _selectedMonth,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 1),
      initialDatePickerMode: DatePickerMode.year,
      helpText: 'Select report month',
      builder: (ctx, child) => Theme(
        data: Theme.of(ctx).copyWith(
          colorScheme: const ColorScheme.light(
            primary: kTeal,
            onPrimary: Colors.white,
            surface: Colors.white,
            onSurface: kNavy,
          ),
        ),
        child: child!,
      ),
    );
    if (picked != null) {
      setState(() => _selectedMonth = DateTime(picked.year, picked.month));
      _loadSummary();
    }
  }

  Future<void> _exportFull({required bool pdf}) async {
    if (_summary == null) return;
    setState(() => _exportingType = pdf ? 'pdf' : 'excel');
    try {
      final drones = await ReportService.fetchDroneInOutReport(
          _selectedMonth.year, _selectedMonth.month);
      final stock = await ReportService.fetchStockHistoryReport(
          _selectedMonth.year, _selectedMonth.month);
      final invoices = await ReportService.fetchInvoiceReport(
          _selectedMonth.year, _selectedMonth.month);
      final label = DateFormat('MMM_yyyy').format(_selectedMonth);

      if (pdf) {
        final bytes = await PdfExportService.buildFullMonthlyReport(
          month: _selectedMonth,
          summary: _summary!,
          drones: drones,
          stock: stock,
          invoices: invoices,
        );
        await PdfExportService.download(bytes, 'Monthly_Report_$label.pdf');
      } else {
        final bytes = ExcelExportService.buildFullMonthlyReport(
          month: _selectedMonth,
          summary: _summary!,
          drones: drones,
          stock: stock,
          invoices: invoices,
        );
        ExcelExportService.download(bytes, 'Monthly_Report_$label.xlsx');
      }
      if (mounted) _showSnack('${pdf ? "PDF" : "Excel"} report downloaded');
    } catch (e) {
      if (mounted) _showSnack('Export failed: $e', isError: true);
    } finally {
      if (mounted) setState(() => _exportingType = null);
    }
  }

  void _showSnack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white, size: 18),
          const SizedBox(width: 8),
          Expanded(child: Text(msg)),
        ]),
        backgroundColor: isError ? kCoral : kGreen,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(12),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kSurface,
      body: RefreshIndicator(
        onRefresh: _loadSummary,
        color: kTeal,
        child: CustomScrollView(
          slivers: [
            // ── Sliver App Bar (matches Invoice List hero header) ──────────
            SliverAppBar(
              expandedHeight: 150,
              floating: false,
              pinned: true,
              backgroundColor: kNavy,
              foregroundColor: Colors.white,
              title: const Text(
                'Reports',
                style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
              ),
              titleSpacing: 0,
              actions: [
                IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: _loadSummary),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFF0A1628), Color(0xFF162944)],
                    ),
                  ),
                  child: ClipRect(
                    child: SafeArea(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            const Text(
                              'Reports',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                  letterSpacing: -0.5),
                            ),
                            const SizedBox(height: 2),
                            const Text(
                              'CDA Inventory System',
                              style: TextStyle(
                                  color: kTeal,
                                  fontSize: 12,
                                  fontWeight: FontWeight.w500,
                                  letterSpacing: 1.2),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                collapseMode: CollapseMode.parallax,
              ),
            ),

            // ── Body ─────────────────────────────────────────────────────────
            if (_loading)
              const SliverFillRemaining(
                child: Center(child: CircularProgressIndicator(color: kTeal)),
              )
            else if (_error != null)
              SliverFillRemaining(child: _errorCard())
            else
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(14, 14, 14, 32),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    _monthSelector(),
                    const SizedBox(height: 14),
                    FadeTransition(opacity: _fadeAnim, child: _summaryGrid()),
                    const SizedBox(height: 16),
                    FadeTransition(opacity: _fadeAnim, child: _fullReportCard()),
                    const SizedBox(height: 20),
                    _sectionLabel('DETAILED REPORTS'),
                    const SizedBox(height: 8),
                    _ReportListTile(
                      icon: Icons.flight_takeoff_rounded,
                      title: 'Drone In / Out',
                      subtitle:
                      '${_summary?.droneInCount ?? 0} in  ·  ${_summary?.droneOutCount ?? 0} out',
                      color: kPurple,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) =>
                                DroneInOutReportScreen(initialMonth: _selectedMonth)),
                      ),
                    ),
                    _ReportListTile(
                      icon: Icons.history_rounded,
                      title: 'Stock / Inventory History',
                      subtitle:
                      '${(_summary?.stockInCount ?? 0) + (_summary?.stockOutCount ?? 0)} transactions',
                      color: kGreen,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) =>
                                StockHistoryReportScreen(initialMonth: _selectedMonth)),
                      ),
                    ),
                    _ReportListTile(
                      icon: Icons.receipt_long_rounded,
                      title: 'Invoice List',
                      subtitle: '${_summary?.invoiceCount ?? 0} invoices',
                      color: kTeal,
                      onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => InvoiceReportScreen(initialMonth: _selectedMonth)),
                      ),
                    ),
                  ]),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _monthSelector() {
    return GestureDetector(
      onTap: _pickMonth,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(14),
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
          ],
        ),
        child: Row(children: [
          Container(
            width: 40,
            height: 40,
            decoration:
            BoxDecoration(color: kTeal.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
            child: const Icon(Icons.calendar_month_rounded, color: kTeal, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('REPORT MONTH',
                  style: TextStyle(
                      color: Colors.grey.shade400,
                      fontSize: 9,
                      letterSpacing: 1,
                      fontWeight: FontWeight.w700)),
              Text(DateFormat('MMMM yyyy').format(_selectedMonth),
                  style: const TextStyle(color: kNavy, fontSize: 16, fontWeight: FontWeight.w700)),
            ]),
          ),
          Icon(Icons.expand_more_rounded, color: Colors.grey.shade400),
        ]),
      ),
    );
  }

  Widget _summaryGrid() {
    final s = _summary!;
    final currency = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0);
    final items = [
      ('Drone IN', '${s.droneInCount}', kGreen, Icons.flight_land_rounded),
      ('Drone OUT', '${s.droneOutCount}', kCoral, Icons.flight_takeoff_rounded),
      ('Stock IN qty', '${s.stockInQty}', kGreen, Icons.arrow_downward_rounded),
      ('Stock OUT qty', '${s.stockOutQty}', kCoral, Icons.arrow_upward_rounded),
      ('Invoices', '${s.invoiceCount}', kPurple, Icons.receipt_long_rounded),
      ('Invoice Total', currency.format(s.invoiceTotal), kTeal, Icons.currency_rupee_rounded),
    ];
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisSpacing: 10,
        crossAxisSpacing: 10,
        mainAxisExtent: 78,
      ),
      itemCount: items.length,
      itemBuilder: (_, i) {
        final it = items[i];
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Icon(it.$4, color: it.$3, size: 14),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(it.$1,
                      style: TextStyle(
                          color: Colors.grey.shade500, fontSize: 10, fontWeight: FontWeight.w600),
                      overflow: TextOverflow.ellipsis),
                ),
              ]),
              const SizedBox(height: 6),
              Text(it.$2, style: TextStyle(color: it.$3, fontSize: 16, fontWeight: FontWeight.w800)),
            ],
          ),
        );
      },
    );
  }

  Widget _fullReportCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFF0A1628), Color(0xFF162944)]),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kTeal.withOpacity(0.4)),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: const [
          Icon(Icons.summarize_rounded, color: Colors.white, size: 18),
          SizedBox(width: 8),
          Text('Monthly Consolidated Report',
              style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
        ]),
        const SizedBox(height: 4),
        Text('Drone, stock & invoice data — everything, one file.',
            style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 11.5)),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(
              child: _exportButton('PDF', Icons.picture_as_pdf_rounded,
                  _exportingType == 'pdf', () => _exportFull(pdf: true))),
          const SizedBox(width: 10),
          Expanded(
              child: _exportButton('Excel', Icons.grid_on_rounded,
                  _exportingType == 'excel', () => _exportFull(pdf: false))),
        ]),
      ]),
    );
  }

  Widget _exportButton(String label, IconData icon, bool busy, VoidCallback onTap) {
    return ElevatedButton.icon(
      onPressed: _exportingType == null ? onTap : null,
      icon: busy
          ? const SizedBox(
          width: 14,
          height: 14,
          child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
          : Icon(icon, size: 16),
      label: Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
      style: ElevatedButton.styleFrom(
        backgroundColor: kTeal,
        foregroundColor: Colors.white,
        // The button being tapped (busy == true) should stay fully solid
        // with its spinner. Only the *other* button — disabled but not the
        // one running — should fade, so colors don't shift on the button
        // you actually clicked.
        disabledBackgroundColor: busy ? kTeal : kTeal.withOpacity(0.5),
        disabledForegroundColor: busy ? Colors.white : Colors.white.withOpacity(0.85),
        padding: const EdgeInsets.symmetric(vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        elevation: 0,
      ),
    );
  }

  Widget _sectionLabel(String text) => Row(children: [
    Container(width: 6, height: 6, decoration: const BoxDecoration(color: kTeal, shape: BoxShape.circle)),
    const SizedBox(width: 7),
    Text(text,
        style: TextStyle(
            color: Colors.grey.shade500, fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.5)),
    const SizedBox(width: 8),
    Expanded(child: Divider(color: Colors.grey.shade300)),
  ]);

  Widget _errorCard() => Center(
    child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(color: kCoral.withOpacity(0.1), shape: BoxShape.circle),
            child: const Icon(Icons.cloud_off_rounded, size: 40, color: kCoral),
          ),
          const SizedBox(height: 20),
          const Text('Failed to load',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: kNavy)),
          const SizedBox(height: 8),
          Text(_error ?? '',
              textAlign: TextAlign.center, style: TextStyle(color: Colors.grey.shade500, fontSize: 13)),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _loadSummary,
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Retry'),
            style: ElevatedButton.styleFrom(
              backgroundColor: kNavy,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      ),
    ),
  );
}

class _ReportListTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  final Color color;
  final VoidCallback onTap;

  const _ReportListTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2)),
        ],
      ),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
        leading: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: color, size: 20),
        ),
        title: Text(title,
            style: const TextStyle(
                color: _ReportsDashboardScreenState.kNavy, fontWeight: FontWeight.w700, fontSize: 14)),
        subtitle: Text(subtitle, style: TextStyle(color: Colors.grey.shade500, fontSize: 11.5)),
        trailing: Icon(Icons.chevron_right_rounded, color: Colors.grey.shade400),
      ),
    );
  }
}